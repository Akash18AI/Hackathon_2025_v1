# DevOps AI Dashboard

## Overview

The DevOps AI Dashboard is an enterprise-grade infrastructure management and automation platform designed specifically for Insurity's multi-product environment. This application provides AI-powered DevOps capabilities including intelligent log analysis, automated playbook execution, and comprehensive server monitoring across different insurance products (SurePALC, Claims Processing, Customer Portal, etc.).

The system serves as a centralized command center for managing complex distributed systems, allowing both administrators and clients to monitor, troubleshoot, and automate operational tasks across test, pre-production, and production environments. Key features include real-time server status monitoring, AI-driven chat interface for log queries, Ansible playbook management, and role-based access control for multi-tenant operations.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The application uses a modern React-based single-page application (SPA) built with TypeScript and Vite for fast development and optimized builds. The UI framework is built on shadcn/ui components with Radix UI primitives, providing a consistent enterprise-grade design system optimized for operational dashboards. The styling uses Tailwind CSS with a dark-mode-first approach, featuring a command center aesthetic with carefully chosen color palettes for operational efficiency.

The component architecture follows a modular approach with specialized components for different operational contexts:
- **Navigation & Layout**: Sidebar-based navigation with product/client/environment selection
- **Data Visualization**: Real-time server status cards, log viewers with syntax highlighting, and progress tracking for playbook execution
- **Interactive Components**: AI chat interface, playbook creation tools, and execution monitoring panels
- **State Management**: React Query for server state management and caching, with local state for UI interactions

### Backend Architecture
The backend is built on Express.js with TypeScript, following a modular route-based architecture. The server implements middleware for request logging, JSON parsing, and error handling. The application uses a layered storage abstraction pattern, currently implementing in-memory storage but designed to easily swap to database-backed storage.

Key architectural decisions:
- **API Design**: RESTful API structure with `/api` prefix for all backend endpoints
- **Storage Layer**: Abstracted storage interface supporting CRUD operations with pluggable implementations
- **Development Setup**: Integrated Vite development server with HMR support and custom error overlays
- **Production Build**: Optimized bundling with esbuild for server-side code and Vite for client assets

### Data Storage Solutions
The application is designed with database flexibility in mind, currently using Drizzle ORM with PostgreSQL support. The schema is structured to handle multi-tenant operations with clear separation between products, clients, environments, and servers.

**Database Schema Design**:
- **User Management**: User authentication with role-based access (admin/client)
- **Product Hierarchy**: Products → Clients → Environments → Servers relationship
- **Playbook System**: Playbook definitions, execution history, and progress tracking
- **Audit Trail**: Comprehensive logging of all operations and changes

**Data Access Patterns**:
- Drizzle ORM for type-safe database interactions
- Connection pooling for production scalability
- Migration system for schema evolution
- Prepared statements for security and performance

### Authentication and Authorization
The system implements a session-based authentication model with role-based access control (RBAC). Users can authenticate as either administrators (full access) or clients (restricted to their assigned environments).

**Security Architecture**:
- Session management with secure HTTP-only cookies
- Role-based permissions enforced at both API and UI levels
- Client isolation ensuring users only access their assigned resources
- Audit logging for all administrative actions

### External Service Integrations
The application is designed to integrate with several external systems and services:

**Infrastructure Monitoring**:
- Server status monitoring APIs
- Log aggregation services for centralized log collection
- Health check endpoints for real-time status updates

**Automation & Orchestration**:
- Ansible playbook execution engine
- SSH connectivity for remote server management
- Configuration management integration

**AI & Analytics**:
- OpenAI API integration for intelligent log analysis and playbook generation
- Natural language processing for chat interface queries
- Automated incident detection and response suggestions

The architecture supports both development and production deployment scenarios, with environment-specific configurations and optimizations. The modular design allows for easy scaling and feature additions as the platform evolves.

## Recent Changes

### Product Overview Client Filtering & Navigation (Latest)
- **Issue Resolved**: ProductOverview component was using hardcoded `allProducts` array instead of filtered products prop, and product selection wasn't navigating to dashboard
- **Root Causes**: 
  1. Component ignored the filtered products passed to it and displayed all products to all users
  2. Product card clicks only updated selection state but didn't navigate to dashboard route
- **Fixes Applied**: 
  1. Updated ProductOverview to use the `products` prop instead of hardcoded data
  2. Added programmatic navigation using wouter's `useLocation` hook to navigate to `/dashboard` after product selection
- **Client-Scoped Metrics**: Metrics now calculate from only the current client's data, not aggregated across all clients
- **Dynamic Descriptions**: Page descriptions now show client-specific text (e.g., "Microsoft Corporation products and infrastructure status")
- **Navigation Flow**: Product card clicks now properly navigate users from Product Overview to product-specific dashboards
- **Status**: Complete - All clients see only their assigned products with accurate metrics and working navigation