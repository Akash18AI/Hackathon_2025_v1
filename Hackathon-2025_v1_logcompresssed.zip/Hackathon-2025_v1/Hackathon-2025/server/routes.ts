import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import fs from "fs/promises";
import path from "path";
import { createReadStream } from "fs";
import { createInterface } from "readline";

export async function registerRoutes(app: Express): Promise<Server> {
  // put application routes here
  // prefix all routes with /api

  // use storage to perform CRUD operations on the storage interface
  // e.g. storage.insertUser(user) or storage.getUserByUsername(username)

  // API endpoint to get logs for a specific product/client/environment
  app.get("/api/logs/:productId/:clientId/:environment", async (req, res) => {
    try {
      const { productId, clientId, environment } = req.params;
      
      // Map environment IDs to folder names
      let folderName = environment;
      if (environment.includes('-')) {
        // Extract the environment type from IDs like 'surepatc-test' -> 'test'
        const parts = environment.split('-');
        folderName = parts[parts.length - 1]; // Get the last part
      }
      
      const logPath = path.join(process.cwd(), "shared", "logs", productId, clientId, folderName);
      
      // Check if directory exists
      try {
        await fs.access(logPath);
      } catch {
        return res.json({ logs: [], error: "No logs found for this environment" });
      }
      
      // Read all log files in the directory
      const files = await fs.readdir(logPath);
      const logFiles = files.filter(file => file.endsWith('.log'));
      
      if (logFiles.length === 0) {
        return res.json({ logs: [], error: "No log files found" });
      }
      
      const allLogs = [];
      
      for (const file of logFiles) {
        const filePath = path.join(logPath, file);
        try {
          // Use efficient tail reading for large files
          const lastLines = await readLastLines(filePath, 2000); // Read last 2000 lines per file
          const parsedLogs = parseLogFile(lastLines, file);
          allLogs.push(...parsedLogs);
        } catch (fileError) {
          console.error(`Error reading file ${file}:`, fileError);
          // Continue processing other files
        }
      }
      
      // Sort logs by timestamp (most recent first)
      allLogs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      
      res.json({ logs: allLogs.slice(0, 1000) }); // Return 1000 most recent logs
    } catch (error) {
      console.error("Error reading logs:", error);
      res.status(500).json({ error: "Failed to read logs" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}

// Efficient function to read last N lines from a file without loading entire file
async function readLastLines(filePath: string, numLines: number): Promise<string> {
  return new Promise((resolve, reject) => {
    const lines: string[] = [];
    const fileStream = createReadStream(filePath, { encoding: 'utf8' });
    const rl = createInterface({
      input: fileStream,
      crlfDelay: Infinity
    });

    rl.on('line', (line) => {
      lines.push(line);
      // Keep only the last numLines in memory
      if (lines.length > numLines) {
        lines.shift();
      }
    });

    rl.on('close', () => {
      resolve(lines.join('\n'));
    });

    rl.on('error', (error) => {
      reject(error);
    });
  });
}

interface LogEntry {
  id: string;
  timestamp: string;
  level: "INFO" | "WARN" | "ERROR" | "DEBUG";
  service: string;
  message: string;
  details?: string;
}

function parseLogFile(content: string, fileName: string): LogEntry[] {
  const logs: LogEntry[] = [];
  const lines = content.split('\n').filter(line => line.trim());
  
  if (fileName.includes('iis_access.log')) {
    return parseIISAccessLogs(lines, fileName);
  } else if (fileName.includes('iis_error.log')) {
    return parseIISErrorLogs(lines, fileName);
  } else if (fileName.includes('application.log')) {
    return parseApplicationLogs(lines, fileName);
  }
  
  return logs;
}

function parseIISAccessLogs(lines: string[], fileName: string): LogEntry[] {
  const logs: LogEntry[] = [];
  
  for (const line of lines) {
    // Skip comment lines
    if (line.startsWith('#') || !line.trim()) continue;
    
    // Parse format: IP - - [timestamp] "METHOD path HTTP/1.1" status size "-" "user-agent"
    const match = line.match(/^(\S+) - - \[([^\]]+)\] "(\S+) (\S+) HTTP\/[\d.]+"\s+(\d+)\s+(\d+)\s+"[^"]*"\s+"([^"]*)"$/);
    if (!match) continue;
    
    const [, clientIP, timestamp, method, uri, status, size, userAgent] = match;
    
    const level = parseInt(status) >= 400 ? "ERROR" : parseInt(status) >= 300 ? "WARN" : "INFO";
    const service = "IIS-WebServer";
    const message = `${method} ${uri} - Status: ${status}`;
    const details = `Client: ${clientIP}, Size: ${size}b, User-Agent: ${userAgent}`;
    
    logs.push({
      id: `iis-${Date.now()}-${Math.random()}`,
      timestamp,
      level,
      service,
      message,
      details
    });
  }
  
  return logs;
}

function parseIISErrorLogs(lines: string[], fileName: string): LogEntry[] {
  const logs: LogEntry[] = [];
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (!line.trim()) continue;
    
    // Parse format: timestamp [ERROR] message - Code: Exxxx
    const match = line.match(/^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) \[ERROR\] (.+) - Code: (E\d+)$/);
    if (match) {
      const [, timestamp, message, errorCode] = match;
      
      // Look for details on next lines
      let details = `Error Code: ${errorCode}`;
      if (i + 1 < lines.length && lines[i + 1].trim().startsWith('Source:')) {
        details += `, ${lines[i + 1].trim()}`;
        i++; // Skip the source line
      }
      if (i + 1 < lines.length && lines[i + 1].trim().startsWith('Details:')) {
        details += `, ${lines[i + 1].trim()}`;
        i++; // Skip the details line
      }
      
      logs.push({
        id: `iis-error-${Date.now()}-${Math.random()}`,
        timestamp,
        level: "ERROR",
        service: "IIS-ErrorLog",
        message,
        details
      });
    }
  }
  
  return logs;
}

function parseApplicationLogs(lines: string[], fileName: string): LogEntry[] {
  const logs: LogEntry[] = [];
  
  for (const line of lines) {
    if (!line.trim()) continue;
    
    // Parse .NET application log format: timestamp [thread] level component - message
    const logPattern = /^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3}) \[(\d+)\] (\w+)\s+(.+?) - (.+)$/;
    const match = line.match(logPattern);
    
    if (match) {
      const [, timestamp, thread, level, component, message] = match;
      
      const normalizedLevel = level.toUpperCase() as "INFO" | "WARN" | "ERROR" | "DEBUG";
      
      logs.push({
        id: `app-${Date.now()}-${Math.random()}`,
        timestamp: timestamp.replace(',', '.'), // Convert to standard format
        level: normalizedLevel,
        service: component || "SurePALC-Application",
        message,
        details: `Thread: ${thread}`
      });
    }
  }
  
  return logs;
}
