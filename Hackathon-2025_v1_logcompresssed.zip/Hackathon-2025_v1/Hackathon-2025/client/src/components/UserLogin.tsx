import { useState } from "react";
import { LogIn, User, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import backgroundImage from "@assets/stock_images/blurred_office_envir_3d8908dc.jpg";

export interface UserSession {
  id: string;
  username: string;
  role: "admin" | "client";
  clientId?: string;
  clientName?: string;
}

interface UserLoginProps {
  onLogin: (session: UserSession) => void;
}

// Authentication credentials determine user role and access
const credentials = {
  // Admin users
  "admin": { password: "admin123", role: "admin" as const },
  // Client users - specific companies with their own product access
  "apple": { password: "apple123", role: "client" as const, clientId: "apple", clientName: "Apple Inc." },
  "google": { password: "google123", role: "client" as const, clientId: "google", clientName: "Google LLC" },
  "microsoft": { password: "microsoft123", role: "client" as const, clientId: "microsoft", clientName: "Microsoft Corporation" },
};

export function UserLogin({ onLogin }: UserLoginProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const handleLogin = async () => {
    setError("");
    
    if (!username || !password) {
      setError("Please enter both username and password");
      return;
    }

    setIsLoading(true);
    console.log(`Login attempt - User: ${username}`);

    // Simulate authentication - role and client determined by credentials
    setTimeout(() => {
      const userCredentials = credentials[username as keyof typeof credentials];
      
      if (!userCredentials || userCredentials.password !== password) {
        setError("Invalid username or password");
        setIsLoading(false);
        return;
      }

      const session: UserSession = {
        id: `user-${Date.now()}`,
        username,
        role: userCredentials.role,
        clientId: userCredentials.role === "client" ? (userCredentials as any).clientId : undefined,
        clientName: userCredentials.role === "client" ? (userCredentials as any).clientName : undefined,
      };

      setIsLoading(false);
      onLogin(session);
    }, 1500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !isLoading) {
      handleLogin();
    }
  };

  return (
    <div 
      className="min-h-screen flex items-center justify-center p-4 relative"
      style={{
        backgroundImage: `url(${backgroundImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }}
    >
      {/* Dark overlay for better contrast */}
      <div className="absolute inset-0 bg-black/60"></div>
      
      <Card className="w-full max-w-md bg-black/80 backdrop-blur-sm shadow-2xl border-gray-700 relative z-10">
        <CardHeader className="text-center">
          <div className="mx-auto mb-6">
            <div className="text-center">
              <h1 className="text-4xl font-bold text-white tracking-wide" style={{ fontFamily: 'system-ui, -apple-system, "Segoe UI", sans-serif', letterSpacing: '0.5px' }}>
                insurity
              </h1>
            </div>
          </div>
          <CardTitle className="text-2xl text-white mb-2">OpsIntelligence Platform</CardTitle>
          <p className="text-gray-300">Insurity Infrastructure Management</p>
        </CardHeader>

        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive" className="bg-red-900/50 border-red-700 text-red-200">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="username" className="text-white">Username</Label>
            <Input
              id="username"
              type="text"
              placeholder="Enter your username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              onKeyPress={handleKeyPress}
              disabled={isLoading}
              data-testid="input-username"
              className="bg-gray-800/80 border-gray-600 text-white placeholder:text-gray-400 focus:border-blue-400"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password" className="text-white">Password</Label>
            <Input
              id="password"
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyPress={handleKeyPress}
              disabled={isLoading}
              data-testid="input-password"
              className="bg-gray-800/80 border-gray-600 text-white placeholder:text-gray-400 focus:border-blue-400"
            />
          </div>


          <Button
            onClick={handleLogin}
            disabled={isLoading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold"
            data-testid="button-login"
          >
            {isLoading ? (
              <>
                <User className="mr-2 h-4 w-4 animate-spin" />
                Signing In...
              </>
            ) : (
              <>
                <LogIn className="mr-2 h-4 w-4" />
                Sign In
              </>
            )}
          </Button>

          <div className="text-center text-sm text-gray-300">
            <p className="mb-2 text-white">Demo Credentials:</p>
            <div className="space-y-1 text-xs">
              <p><strong className="text-white">Admin:</strong> admin / admin123</p>
              <p><strong className="text-white">Apple:</strong> apple / apple123</p>
              <p><strong className="text-white">Google:</strong> google / google123</p>
              <p><strong className="text-white">Microsoft:</strong> microsoft / microsoft123</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}