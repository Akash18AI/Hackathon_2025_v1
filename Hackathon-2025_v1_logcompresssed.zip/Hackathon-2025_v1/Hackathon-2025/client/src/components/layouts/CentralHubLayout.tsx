import { Link, useLocation } from "wouter";
import { ThemeToggle } from "@/components/ThemeToggle";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart3, 
  Brain, 
  FileText, 
  Play, 
  Activity, 
  Server,
  User,
  LogOut,
  Settings,
  Shield
} from "lucide-react";
import { ProductSelector, type Product } from "@/components/ProductSelector";
import type { UserSession } from "@/components/UserLogin";

interface CentralHubLayoutProps {
  products: Product[];
  selectedProduct?: string;
  selectedClient?: string;
  selectedEnvironment?: string;
  userSession: UserSession;
  userRole: "admin" | "client";
  userClientId?: string;
  onSelectionChange: (selection: { productId?: string; clientId?: string; environmentId?: string }) => void;
  onLogout: () => void;
  children: React.ReactNode;
}

const navigationCards = [
  { 
    path: "/", 
    label: "Dashboard", 
    icon: BarChart3, 
    description: "System overview and real-time metrics",
    color: "border-blue-500/20 bg-blue-500/5 hover:bg-blue-500/10"
  },
  { 
    path: "/ai-analysis", 
    label: "AI Analysis", 
    icon: Brain, 
    description: "Intelligent insights and recommendations",
    color: "border-purple-500/20 bg-purple-500/5 hover:bg-purple-500/10"
  },
  { 
    path: "/logs", 
    label: "Log Viewer", 
    icon: FileText, 
    description: "System logs and error tracking",
    color: "border-green-500/20 bg-green-500/5 hover:bg-green-500/10"
  },
  { 
    path: "/playbooks", 
    label: "Playbooks", 
    icon: Play, 
    description: "Automated DevOps procedures",
    color: "border-orange-500/20 bg-orange-500/5 hover:bg-orange-500/10"
  },
  { 
    path: "/monitoring", 
    label: "Monitoring", 
    icon: Activity, 
    description: "Performance and health monitoring",
    color: "border-red-500/20 bg-red-500/5 hover:bg-red-500/10"
  },
];

export function CentralHubLayout({
  products,
  selectedProduct,
  selectedClient,
  selectedEnvironment,
  userSession,
  userRole,
  userClientId,
  onSelectionChange,
  onLogout,
  children
}: CentralHubLayoutProps) {
  const [location] = useLocation();

  const getCurrentContext = () => {
    if (!selectedProduct) return "No product selected";
    
    const product = products.find(p => p.id === selectedProduct);
    const client = product?.clients.find(c => c.id === selectedClient);
    const environment = client?.environments.find(e => e.id === selectedEnvironment);
    
    if (!client) return `${product?.name}`;
    if (!environment) return `${product?.name} - ${client.name}`;
    
    return `${product?.name} - ${client.name} - ${environment.name}`;
  };

  // Show central hub for dashboard, otherwise show regular content
  const showCentralHub = location === "/";

  return (
    <div className="min-h-screen bg-background">
      {/* Minimal Top Bar */}
      <header className="border-b bg-card/50 backdrop-blur supports-[backdrop-filter]:bg-card/20">
        <div className="container mx-auto px-6">
          <div className="flex items-center justify-between h-14">
            <Link href="/">
              <div className="flex items-center gap-2 hover-elevate rounded-lg px-3 py-2">
                <div className="w-6 h-6 bg-blue-600 rounded-md flex items-center justify-center">
                  <Server className="w-3 h-3 text-white" />
                </div>
                <span className="font-bold">DevOps AI</span>
              </div>
            </Link>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm font-medium">{userSession.username}</span>
                <Badge variant="secondary" className="text-xs capitalize">{userSession.role}</Badge>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" onClick={onLogout}>
                  <LogOut className="w-4 h-4" />
                </Button>
                <ThemeToggle />
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6">
        {showCentralHub ? (
          <div className="py-12">
            {/* Central Command Header */}
            <div className="text-center mb-12">
              <h1 className="text-4xl font-bold mb-4">DevOps Command Center</h1>
              <p className="text-xl text-muted-foreground mb-8">Insurity Infrastructure Management</p>
              
              {/* Context Display */}
              <div className="max-w-2xl mx-auto mb-8">
                <div className="flex items-center justify-center gap-4 mb-4">
                  <Badge variant="outline" className="px-4 py-2">
                    <Shield className="w-4 h-4 mr-2" />
                    {getCurrentContext()}
                  </Badge>
                </div>
                <ProductSelector
                  products={products}
                  selectedProduct={selectedProduct}
                  selectedClient={selectedClient}
                  selectedEnvironment={selectedEnvironment}
                  userRole={userRole}
                  userClientId={userClientId}
                  onSelectionChange={onSelectionChange}
                />
              </div>
            </div>

            {/* Central Navigation Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
              {navigationCards.map((item) => (
                <Link key={item.path} href={item.path}>
                  <Card className={`transition-all duration-200 hover-elevate cursor-pointer h-full ${item.color}`}>
                    <CardHeader className="pb-4">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-lg bg-background/80">
                          <item.icon className="w-6 h-6" />
                        </div>
                        <CardTitle className="text-lg">{item.label}</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-sm">
                        {item.description}
                      </CardDescription>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto mt-12">
              <Card className="text-center">
                <CardContent className="pt-6">
                  <div className="text-2xl font-bold text-green-600">12</div>
                  <p className="text-xs text-muted-foreground">Active Services</p>
                </CardContent>
              </Card>
              <Card className="text-center">
                <CardContent className="pt-6">
                  <div className="text-2xl font-bold text-blue-600">3</div>
                  <p className="text-xs text-muted-foreground">Environments</p>
                </CardContent>
              </Card>
              <Card className="text-center">
                <CardContent className="pt-6">
                  <div className="text-2xl font-bold text-orange-600">2</div>
                  <p className="text-xs text-muted-foreground">Warnings</p>
                </CardContent>
              </Card>
              <Card className="text-center">
                <CardContent className="pt-6">
                  <div className="text-2xl font-bold text-purple-600">15</div>
                  <p className="text-xs text-muted-foreground">Playbooks</p>
                </CardContent>
              </Card>
            </div>
          </div>
        ) : (
          <div className="py-8">
            {/* Breadcrumb Navigation */}
            <div className="flex items-center gap-2 mb-6">
              <Link href="/">
                <Button variant="ghost" size="sm">Dashboard</Button>
              </Link>
              <span className="text-muted-foreground">/</span>
              <span className="text-sm font-medium">
                {navigationCards.find(item => item.path === location)?.label || 'Page'}
              </span>
            </div>
            
            {children}
          </div>
        )}
      </main>
    </div>
  );
}