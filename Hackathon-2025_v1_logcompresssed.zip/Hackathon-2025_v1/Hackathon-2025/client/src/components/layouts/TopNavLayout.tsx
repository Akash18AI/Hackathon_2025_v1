import { useState } from "react";
import { Link, useLocation } from "wouter";
import { ThemeToggle } from "@/components/ThemeToggle";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart3, 
  Brain, 
  FileText, 
  Play, 
  Activity, 
  Server,
  User,
  LogOut,
  ChevronDown
} from "lucide-react";
import { ProductSelector, type Product } from "@/components/ProductSelector";
import type { UserSession } from "@/components/UserLogin";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface TopNavLayoutProps {
  products: Product[];
  selectedProduct?: string;
  selectedClient?: string;
  selectedEnvironment?: string;
  userSession: UserSession;
  userRole: "admin" | "client";
  userClientId?: string;
  onSelectionChange: (selection: { productId?: string; clientId?: string; environmentId?: string }) => void;
  onLogout: () => void;
  children: React.ReactNode;
}

const navigationItems = [
  { path: "/", label: "Dashboard", icon: BarChart3, description: "System Overview" },
  { path: "/ai-analysis", label: "AI Analysis", icon: Brain, description: "Intelligent Insights" },
  { path: "/logs", label: "Log Viewer", icon: FileText, description: "System Logs" },
  { path: "/playbooks", label: "Playbooks", icon: Play, description: "Automation Scripts" },
  { path: "/monitoring", label: "Monitoring", icon: Activity, description: "Real-time Metrics" },
];

export function TopNavLayout({
  products,
  selectedProduct,
  selectedClient,
  selectedEnvironment,
  userSession,
  userRole,
  userClientId,
  onSelectionChange,
  onLogout,
  children
}: TopNavLayoutProps) {
  const [location] = useLocation();

  const getCurrentContext = () => {
    if (!selectedProduct) return "Select a product to begin";
    
    const product = products.find(p => p.id === selectedProduct);
    const client = product?.clients.find(c => c.id === selectedClient);
    const environment = client?.environments.find(e => e.id === selectedEnvironment);
    
    if (!client) return `${product?.name} - Select client`;
    if (!environment) return `${product?.name} - ${client.name} - Select environment`;
    
    return `${product?.name} - ${client.name} - ${environment.name}`;
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Top Navigation Bar */}
      <header className="border-b bg-card/50 backdrop-blur supports-[backdrop-filter]:bg-card/20">
        <div className="container mx-auto px-6">
          <div className="flex items-center justify-between h-16 py-2">
            {/* Logo and Branding */}
            <div className="flex items-center gap-4 min-w-0 flex-shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Server className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h1 className="font-bold text-lg">DevOps AI</h1>
                  <p className="text-xs text-muted-foreground">Insurity Infrastructure</p>
                </div>
              </div>
            </div>

            {/* Central Navigation */}
            <nav className="hidden md:flex items-center gap-1 flex-1 justify-center max-w-none">
              {navigationItems.map((item) => {
                const isActive = location === item.path;
                return (
                  <Link key={item.path} href={item.path}>
                    <Button
                      variant={isActive ? "secondary" : "ghost"}
                      className="gap-2 h-9"
                      data-testid={`nav-${item.label.toLowerCase().replace(' ', '-')}`}
                    >
                      <item.icon className="w-4 h-4" />
                      {item.label}
                    </Button>
                  </Link>
                );
              })}
            </nav>

            {/* User Info and Controls */}
            <div className="flex items-center gap-3 min-w-0 flex-shrink-0">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="gap-2 h-9">
                    <User className="w-4 h-4" />
                    <span className="hidden md:inline">{userSession.username}</span>
                    <ChevronDown className="w-3 h-3" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem className="text-xs">
                    Role: <Badge variant="secondary" className="ml-2 capitalize">{userSession.role}</Badge>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={onLogout} className="text-red-600">
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      {/* Context Bar */}
      <div className="border-b bg-muted/20">
        <div className="container mx-auto px-6">
          <div className="flex items-center justify-between h-12">
            <div className="flex items-center gap-4">
              <div className="text-sm font-medium text-muted-foreground">
                Current Context:
              </div>
              <Badge variant="outline" className="text-xs">
                {getCurrentContext()}
              </Badge>
            </div>
            <div className="max-w-md">
              <ProductSelector
                products={products}
                selectedProduct={selectedProduct}
                selectedClient={selectedClient}
                selectedEnvironment={selectedEnvironment}
                userRole={userRole}
                userClientId={userClientId}
                onSelectionChange={onSelectionChange}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <main className="container mx-auto px-6 py-8">
        {children}
      </main>
    </div>
  );
}