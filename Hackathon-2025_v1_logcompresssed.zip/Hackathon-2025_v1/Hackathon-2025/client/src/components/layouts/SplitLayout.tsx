import { Link, useLocation } from "wouter";
import { ThemeToggle } from "@/components/ThemeToggle";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  BarChart3, 
  Brain, 
  FileText, 
  Play, 
  Activity, 
  Server,
  User,
  LogOut,
  ChevronRight
} from "lucide-react";
import { ProductSelector, type Product } from "@/components/ProductSelector";
import type { UserSession } from "@/components/UserLogin";

interface SplitLayoutProps {
  products: Product[];
  selectedProduct?: string;
  selectedClient?: string;
  selectedEnvironment?: string;
  userSession: UserSession;
  userRole: "admin" | "client";
  userClientId?: string;
  onSelectionChange: (selection: { productId?: string; clientId?: string; environmentId?: string }) => void;
  onLogout: () => void;
  children: React.ReactNode;
}

const navigationItems = [
  { path: "/", label: "Dashboard", icon: BarChart3 },
  { path: "/ai-analysis", label: "AI Analysis", icon: Brain },
  { path: "/logs", label: "Log Viewer", icon: FileText },
  { path: "/playbooks", label: "Playbooks", icon: Play },
  { path: "/monitoring", label: "Monitoring", icon: Activity },
];

export function SplitLayout({
  products,
  selectedProduct,
  selectedClient,
  selectedEnvironment,
  userSession,
  userRole,
  userClientId,
  onSelectionChange,
  onLogout,
  children
}: SplitLayoutProps) {
  const [location] = useLocation();

  const getCurrentContext = () => {
    if (!selectedProduct) return "Select a product to begin";
    
    const product = products.find(p => p.id === selectedProduct);
    const client = product?.clients.find(c => c.id === selectedClient);
    const environment = client?.environments.find(e => e.id === selectedEnvironment);
    
    if (!client) return `${product?.name} - Select client`;
    if (!environment) return `${product?.name} - ${client.name} - Select environment`;
    
    return `${product?.name} - ${client.name} - ${environment.name}`;
  };

  return (
    <div className="min-h-screen bg-background flex">
      {/* Left Sidebar - Minimal */}
      <aside className="w-16 border-r bg-card/50 flex flex-col">
        <div className="p-3 border-b">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
            <Server className="w-5 h-5 text-white" />
          </div>
        </div>
        
        <nav className="flex-1 p-2">
          <div className="space-y-2">
            {navigationItems.map((item) => {
              const isActive = location === item.path;
              return (
                <Link key={item.path} href={item.path}>
                  <Button
                    variant={isActive ? "secondary" : "ghost"}
                    size="icon"
                    className="w-full h-12"
                    data-testid={`nav-${item.label.toLowerCase().replace(' ', '-')}`}
                    title={item.label}
                  >
                    <item.icon className="w-5 h-5" />
                  </Button>
                </Link>
              );
            })}
          </div>
        </nav>

        <div className="p-2 border-t">
          <Button
            variant="ghost"
            size="icon"
            className="w-full h-12"
            onClick={onLogout}
            title="Logout"
          >
            <LogOut className="w-5 h-5" />
          </Button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col">
        {/* Top Header Bar */}
        <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div>
                  <h1 className="text-xl font-bold">DevOps AI Dashboard</h1>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span>Insurity Infrastructure</span>
                    <ChevronRight className="w-3 h-3" />
                    <span>{navigationItems.find(item => item.path === location)?.label || 'Page'}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm font-medium">{userSession.username}</span>
                  <Badge variant="secondary" className="text-xs capitalize">{userSession.role}</Badge>
                </div>
                <ThemeToggle />
              </div>
            </div>
          </div>
        </header>

        {/* Central Control Panel */}
        <div className="border-b bg-muted/30">
          <div className="px-6 py-4">
            <div className="max-w-4xl mx-auto">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="text-sm font-medium text-muted-foreground">Current Context:</div>
                  <Badge variant="outline" className="text-xs">
                    {getCurrentContext()}
                  </Badge>
                </div>
                <div className="flex-1 max-w-md ml-8">
                  <ProductSelector
                    products={products}
                    selectedProduct={selectedProduct}
                    selectedClient={selectedClient}
                    selectedEnvironment={selectedEnvironment}
                    userRole={userRole}
                    userClientId={userClientId}
                    onSelectionChange={onSelectionChange}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content - Centered */}
        <main className="flex-1 overflow-hidden">
          <div className="h-full px-6 py-8">
            <div className="max-w-7xl mx-auto h-full">
              {children}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}