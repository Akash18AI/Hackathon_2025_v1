import { Database, Globe, Server, Cpu } from "lucide-react";
import { cn } from "@/lib/utils";

type ServerType = "app" | "web" | "database" | "rsp" | "apppool";

interface ServerTypeIconProps {
  type: ServerType;
  className?: string;
  size?: number;
}

const serverTypeConfig = {
  app: {
    icon: Cpu,
    color: "text-blue-400",
    label: "Application Server"
  },
  web: {
    icon: Globe,
    color: "text-green-400", 
    label: "Web Server"
  },
  database: {
    icon: Database,
    color: "text-purple-400",
    label: "Database Server"
  },
  rsp: {
    icon: Server,
    color: "text-orange-400",
    label: "RSP Server"
  },
  apppool: {
    icon: Cpu,
    color: "text-cyan-400",
    label: "Application Pool"
  },
};

export function ServerTypeIcon({ type, className, size = 16 }: ServerTypeIconProps) {
  const config = serverTypeConfig[type];
  const Icon = config.icon;
  
  return (
    <Icon 
      size={size}
      className={cn(config.color, className)}
      data-testid={`icon-server-${type}`}
    />
  );
}