import { useState } from "react";
import { Play, Clock, CheckCircle, AlertTriangle, Settings, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export interface Playbook {
  id: string;
  name: string;
  description: string;
  category: "database" | "networking" | "application" | "system" | "monitoring" | "performance";
  difficulty: "low" | "medium" | "high";
  estimatedTime: string;
  lastRun?: Date;
  successRate: number;
  tags: string[];
}

interface PlaybookDashboardProps {
  playbooks: Playbook[];
  onExecutePlaybook: (playbookId: string) => void;
}

const categoryConfig = {
  database: { icon: "🗄️", color: "bg-purple-500/10 text-purple-600" },
  networking: { icon: "🌐", color: "bg-blue-500/10 text-blue-600" },
  application: { icon: "⚙️", color: "bg-green-500/10 text-green-600" },
  system: { icon: "🖥️", color: "bg-orange-500/10 text-orange-600" },
  monitoring: { icon: "📊", color: "bg-cyan-500/10 text-cyan-600" },
  performance: { icon: "⚡", color: "bg-yellow-500/10 text-yellow-600" },
};

const difficultyConfig = {
  low: { variant: "secondary" as const, label: "Low Risk" },
  medium: { variant: "secondary" as const, label: "Medium Risk" },
  high: { variant: "destructive" as const, label: "High Risk" },
};

export function PlaybookDashboard({ playbooks, onExecutePlaybook }: PlaybookDashboardProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const filteredPlaybooks = playbooks.filter(playbook => {
    const matchesSearch = playbook.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         playbook.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         playbook.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = selectedCategory === "all" || playbook.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleExecute = (playbookId: string, playbookName: string) => {
    console.log(`Executing playbook: ${playbookName} (${playbookId})`);
    onExecutePlaybook(playbookId);
  };

  const categories = ["all", ...Array.from(new Set(playbooks.map(p => p.category)))];

  return (
    <Card className="flex flex-col h-full">
      <CardHeader className="flex-shrink-0">
        <CardTitle className="flex items-center gap-2">
          <Settings className="h-5 w-5" />
          Ansible Playbooks
        </CardTitle>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col gap-4 p-0">
        <div className="flex-shrink-0 px-6 space-y-4">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search playbooks..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
                data-testid="input-playbook-search"
              />
            </div>
          </div>

          <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="w-full">
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="all">All ({playbooks.length})</TabsTrigger>
              <TabsTrigger value="application">App</TabsTrigger>
              <TabsTrigger value="system">System</TabsTrigger>
              <TabsTrigger value="database">Database</TabsTrigger>
              <TabsTrigger value="monitoring">Monitor</TabsTrigger>
              <TabsTrigger value="performance">Perf</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        <ScrollArea className="flex-1 px-6" data-testid="playbook-list">
          {filteredPlaybooks.length === 0 ? (
            <div className="text-center text-muted-foreground py-8">
              <Search className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p className="text-sm">No playbooks match your search criteria</p>
            </div>
          ) : (
            <div className="space-y-3 pb-4">
              {filteredPlaybooks.map((playbook) => (
                <Card key={playbook.id} className="p-4 hover-elevate">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">
                          {categoryConfig[playbook.category].icon}
                        </span>
                        <h3 className="font-medium text-sm">{playbook.name}</h3>
                        <Badge variant={difficultyConfig[playbook.difficulty].variant} className="text-xs">
                          {difficultyConfig[playbook.difficulty].label}
                        </Badge>
                      </div>
                      
                      <p className="text-sm text-muted-foreground">
                        {playbook.description}
                      </p>
                      
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          <span>{playbook.estimatedTime}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <CheckCircle className="h-3 w-3" />
                          <span>{playbook.successRate}% success</span>
                        </div>
                        {playbook.lastRun && (
                          <span>
                            Last run: {playbook.lastRun.toLocaleDateString()}
                          </span>
                        )}
                      </div>
                      
                      <div className="flex flex-wrap gap-1">
                        {playbook.tags.map((tag) => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    
                    <Button
                      onClick={() => handleExecute(playbook.id, playbook.name)}
                      className="flex-shrink-0"
                      data-testid={`button-execute-${playbook.id}`}
                    >
                      <Play className="h-4 w-4 mr-2" />
                      Execute
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}