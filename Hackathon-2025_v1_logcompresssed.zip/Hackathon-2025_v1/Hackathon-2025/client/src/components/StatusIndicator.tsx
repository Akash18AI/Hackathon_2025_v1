import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

type ServerStatus = "online" | "warning" | "error" | "maintenance";

interface StatusIndicatorProps {
  status: ServerStatus;
  label?: string;
  showText?: boolean;
  className?: string;
}

const statusConfig = {
  online: {
    color: "bg-green-500",
    text: "Online",
    variant: "default" as const,
  },
  warning: {
    color: "bg-yellow-500", 
    text: "Warning",
    variant: "secondary" as const,
  },
  error: {
    color: "bg-red-500",
    text: "Error",
    variant: "destructive" as const,
  },
  maintenance: {
    color: "bg-blue-500",
    text: "Maintenance",
    variant: "secondary" as const,
  },
};

export function StatusIndicator({ 
  status, 
  label, 
  showText = false, 
  className 
}: StatusIndicatorProps) {
  const config = statusConfig[status];
  
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <div
        className={cn(
          "h-2 w-2 rounded-full",
          config.color,
          status === "warning" && "animate-pulse"
        )}
        data-testid={`status-indicator-${status}`}
      />
      {showText && (
        <Badge variant={config.variant} className="text-xs">
          {label || config.text}
        </Badge>
      )}
    </div>
  );
}