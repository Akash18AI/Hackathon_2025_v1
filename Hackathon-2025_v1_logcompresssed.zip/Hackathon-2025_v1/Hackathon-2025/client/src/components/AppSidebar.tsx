import { Calendar, Settings, Home, Activity, LayoutGrid } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
} from "@/components/ui/sidebar";
import { ProductSelector, type Product } from "./ProductSelector";
import type { UserSession } from "./UserLogin";

interface AppSidebarProps {
  products: Product[];
  selectedProduct?: string;
  selectedClient?: string;
  selectedEnvironment?: string;
  userRole?: "admin" | "client";
  userClientId?: string;
  onSelectionChange: (selection: {
    productId?: string;
    clientId?: string;
    environmentId?: string;
  }) => void;
  userSession: UserSession;
}

// Navigation items
const navigationItems = [
  {
    title: "Dashboard",
    url: "/",
    icon: Home,
  },
  {
    title: "AI Analysis", 
    url: "/ai-analysis",
    icon: Activity,
  },
  {
    title: "AI Logs Viewer",
    url: "/logs",
    icon: Calendar,
  },
  {
    title: "Playbooks",
    url: "/playbooks", 
    icon: Settings,
  },
  {
    title: "Infra Layout",
    url: "/monitoring",
    icon: Activity,
  },
  {
    title: "Products",
    url: "/products",
    icon: LayoutGrid,
  },
];

export function AppSidebar({ 
  products, 
  selectedProduct, 
  selectedClient,
  selectedEnvironment,
  userRole,
  userClientId,
  onSelectionChange,
  userSession
}: AppSidebarProps) {
  return (
    <Sidebar>
      <SidebarHeader className="p-6">
        <div className="flex items-center gap-3">
          <div className="flex flex-col items-start">
            <h1 className="text-2xl font-bold text-sidebar-foreground tracking-wide mb-1" style={{ fontFamily: 'system-ui, -apple-system, "Segoe UI", sans-serif', letterSpacing: '0.5px' }}>
              insurity
            </h1>
            <h2 className="text-sm font-semibold text-sidebar-foreground">OpsIntelligence Platform</h2>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {navigationItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton 
                    asChild 
                    className="hover-elevate"
                    data-testid={`nav-${item.title.toLowerCase()}`}
                  >
                    <a href={item.url}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup className="mt-6">
          <SidebarGroupContent>
            <ProductSelector 
              products={products}
              selectedProduct={selectedProduct}
              selectedClient={selectedClient}
              selectedEnvironment={selectedEnvironment}
              userRole={userRole}
              userClientId={userClientId}
              onSelectionChange={onSelectionChange}
            />
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}