import { useState, useRef, useEffect } from "react";
import { Send, Bot, User, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";

interface ChatMessage {
  id: string;
  type: "user" | "ai";
  content: string;
  timestamp: Date;
  sources?: string[];
}

interface ChatInterfaceProps {
  selectedProduct?: string;
  selectedClient?: string;
  selectedEnvironment?: string;
  onLogQuery: (query: string, productId?: string) => void;
}

export function ChatInterface({ 
  selectedProduct, 
  selectedClient, 
  selectedEnvironment, 
  onLogQuery 
}: ChatInterfaceProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Auto-scroll to bottom when new messages arrive
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: "user",
      content: inputValue.trim(),
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue("");
    setIsLoading(true);
    
    console.log(`AI query: ${inputValue.trim()} for product: ${selectedProduct}`);
    onLogQuery(inputValue.trim(), selectedProduct);

    // Fetch real logs and analyze them (in real app, this would also call OpenAI API)
    if (selectedProduct && selectedClient && selectedEnvironment) {
      try {
        const response = await fetch(`/api/logs/${selectedProduct}/${selectedClient}/${selectedEnvironment}`);
        const data = await response.json();
        
        if (!response.ok) {
          throw new Error(data.error || `HTTP ${response.status}: ${response.statusText}`);
        }
        
        const logs = data.logs || [];
        
        if (logs.length === 0) {
          const aiMessage: ChatMessage = {
            id: `ai-${Date.now()}`,
            type: "ai",
            content: data.error || "No logs found for the selected environment. Please check your selection or try refreshing.",
            timestamp: new Date(),
          };
          setMessages(prev => [...prev, aiMessage]);
          setIsLoading(false);
          return;
        }
        
        const errorLogs = logs.filter((log: any) => log.level === "ERROR");
        const warnLogs = logs.filter((log: any) => log.level === "WARN");
        const query = inputValue.trim().toLowerCase();
        const relevantLogs = logs.filter((log: any) => 
          log.message.toLowerCase().includes(query) || 
          log.service.toLowerCase().includes(query)
        );
        
        let aiContent = "";
        let sources: string[] = [];
        
        if (relevantLogs.length > 0) {
          const recentLog = relevantLogs[0];
          aiContent = `I found ${relevantLogs.length} log entries related to "${inputValue.trim()}" in your ${selectedEnvironment} environment. `;
          
          if (errorLogs.length > 0) {
            aiContent += `I detected ${errorLogs.length} ERROR level entries. `;
            const recentError = errorLogs[0];
            aiContent += `Most recent error: "${recentError.message}" from ${recentError.service}. `;
          }
          
          if (warnLogs.length > 0) {
            aiContent += `Also found ${warnLogs.length} WARNING level entries that may need attention. `;
          }
          
          aiContent += `Based on the log analysis, I recommend checking the ${recentLog.service} service for potential issues.`;
          sources = Array.from(new Set(logs.map((log: any) => log.service)));
        } else {
          aiContent = `I analyzed ${logs.length} log entries but couldn't find specific matches for "${inputValue.trim()}". However, I found ${errorLogs.length} errors and ${warnLogs.length} warnings in your ${selectedEnvironment} environment that might be worth investigating.`;
          sources = logs.length > 0 ? Array.from(new Set(logs.map((log: any) => log.service))) : [];
        }
        
        setTimeout(() => {
          const aiMessage: ChatMessage = {
            id: (Date.now() + 1).toString(),
            type: "ai",
            content: aiContent,
            timestamp: new Date(),
            sources,
          };
          setMessages(prev => [...prev, aiMessage]);
          setIsLoading(false);
        }, 1500);
        
      } catch (error) {
        setTimeout(() => {
          const aiMessage: ChatMessage = {
            id: (Date.now() + 1).toString(),
            type: "ai",
            content: "I encountered an error while analyzing your logs. Please make sure the environment is properly configured and try again.",
            timestamp: new Date(),
          };
          setMessages(prev => [...prev, aiMessage]);
          setIsLoading(false);
        }, 1000);
      }
    } else {
      setTimeout(() => {
        const aiMessage: ChatMessage = {
          id: (Date.now() + 1).toString(),
          type: "ai",
          content: "Please select a product, client, and environment first to analyze logs. I can help you investigate server issues, error patterns, and performance problems once you choose a specific environment.",
          timestamp: new Date(),
        };
        setMessages(prev => [...prev, aiMessage]);
        setIsLoading(false);
      }, 1000);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Card className="flex flex-col h-full">
      <CardHeader className="flex-shrink-0">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Bot className="h-5 w-5" />
          AI Log Analysis
        </CardTitle>
        {selectedProduct && selectedClient && selectedEnvironment && (
          <Badge variant="outline" className="w-fit">
            Analyzing: {selectedProduct} • {selectedClient} • {selectedEnvironment}
          </Badge>
        )}
      </CardHeader>
      
      <CardContent className="flex-1 flex flex-col gap-4 p-0">
        <ScrollArea 
          className="flex-1 px-6"
          ref={scrollAreaRef}
          data-testid="chat-messages"
        >
          <div className="space-y-4 pb-4">
            {messages.length === 0 && (
              <div className="text-center text-muted-foreground py-8">
                <Bot className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p className="text-sm">
                  {selectedProduct && selectedClient && selectedEnvironment 
                    ? "Ask me anything about your server logs and infrastructure issues."
                    : "Select a product, client, and environment to start analyzing logs with AI assistance."
                  }
                </p>
              </div>
            )}
            
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${
                  message.type === "user" ? "justify-end" : "justify-start"
                }`}
              >
                {message.type === "ai" && (
                  <div className="flex-shrink-0">
                    <Bot className="h-6 w-6 text-primary" />
                  </div>
                )}
                
                <div
                  className={`max-w-[80%] rounded-lg px-3 py-2 ${
                    message.type === "user"
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted"
                  }`}
                >
                  <p className="text-sm">{message.content}</p>
                  
                  {message.sources && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {message.sources.map((source, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {source}
                        </Badge>
                      ))}
                    </div>
                  )}
                  
                  <p className="text-xs opacity-70 mt-1">
                    {message.timestamp.toLocaleTimeString()}
                  </p>
                </div>
                
                {message.type === "user" && (
                  <div className="flex-shrink-0">
                    <User className="h-6 w-6 text-muted-foreground" />
                  </div>
                )}
              </div>
            ))}
            
            {isLoading && (
              <div className="flex gap-3 justify-start">
                <Bot className="h-6 w-6 text-primary flex-shrink-0" />
                <div className="bg-muted rounded-lg px-3 py-2">
                  <div className="flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span className="text-sm text-muted-foreground">Analyzing logs...</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>
        
        <div className="flex-shrink-0 px-6 pb-6">
          <div className="flex gap-2">
            <Input
              ref={inputRef}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder={selectedProduct && selectedClient && selectedEnvironment 
                ? "Ask about errors, performance issues, or server status..."
                : "Select product, client, and environment first..."
              }
              disabled={!selectedProduct || !selectedClient || !selectedEnvironment || isLoading}
              data-testid="input-chat-message"
            />
            <Button
              onClick={handleSendMessage}
              disabled={!selectedProduct || !selectedClient || !selectedEnvironment || !inputValue.trim() || isLoading}
              size="icon"
              data-testid="button-send-message"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}