import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Sidebar, 
  Layout, 
  LayoutDashboard, 
  LayoutGrid,
  Check
} from "lucide-react";

interface LayoutSwitcherProps {
  currentLayout: string;
  onLayoutChange: (layout: string) => void;
}

const layoutOptions = [
  {
    id: "sidebar",
    name: "Sidebar Layout",
    description: "Traditional left sidebar with navigation",
    icon: Sidebar,
    preview: "Current layout with full sidebar navigation"
  },
  {
    id: "topnav",
    name: "Top Navigation",
    description: "Horizontal navigation bar with central content",
    icon: Layout,
    preview: "Clean top navigation with centered dashboard grid"
  },
  {
    id: "central",
    name: "Central Hub",
    description: "Command center with radial navigation cards",
    icon: LayoutDashboard,
    preview: "Central command hub with card-based navigation"
  },
  {
    id: "split",
    name: "Split Layout",
    description: "Minimal sidebar with central content area",
    icon: LayoutGrid,
    preview: "Compact sidebar with focused central workspace"
  }
];

export function LayoutSwitcher({ currentLayout, onLayoutChange }: LayoutSwitcherProps) {
  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold mb-2">Layout Designs</h2>
        <p className="text-muted-foreground">
          Choose from different layout variations that position content in the middle of the page
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {layoutOptions.map((layout) => {
          const isActive = currentLayout === layout.id;
          return (
            <Card 
              key={layout.id} 
              className={`cursor-pointer transition-all hover-elevate ${
                isActive ? 'ring-2 ring-blue-500 bg-blue-500/5' : ''
              }`}
              onClick={() => onLayoutChange(layout.id)}
              data-testid={`card-layout-${layout.id}`}
            >
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${isActive ? 'bg-blue-500 text-white' : 'bg-muted'}`}>
                      <layout.icon className="w-5 h-5" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{layout.name}</CardTitle>
                      <CardDescription>{layout.description}</CardDescription>
                    </div>
                  </div>
                  {isActive && (
                    <Badge variant="default" className="bg-blue-500">
                      <Check className="w-3 h-3 mr-1" />
                      Active
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  {layout.preview}
                </p>
                <Button 
                  variant={isActive ? "secondary" : "outline"} 
                  className="w-full mt-4"
                  onClick={(e) => {
                    e.stopPropagation();
                    onLayoutChange(layout.id);
                  }}
                  data-testid={`button-apply-layout-${layout.id}`}
                >
                  {isActive ? "Currently Active" : "Apply Layout"}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="mt-8 p-4 bg-muted/50 rounded-lg">
        <h3 className="font-semibold mb-2">Layout Features</h3>
        <ul className="text-sm text-muted-foreground space-y-1">
          <li>• <strong>Top Navigation:</strong> Horizontal nav bar with content grid in center</li>
          <li>• <strong>Central Hub:</strong> Command center dashboard with navigation cards in middle</li>
          <li>• <strong>Split Layout:</strong> Minimal sidebar with central workspace area</li>
          <li>• <strong>Sidebar Layout:</strong> Traditional full sidebar (current design)</li>
        </ul>
      </div>
    </div>
  );
}