import { useState } from "react";
import { LogViewer } from "../LogViewer";

export default function LogViewerExample() {
  const [selectedProduct] = useState("insurance-core");

  return (
    <div className="h-96 w-full max-w-2xl">
      <LogViewer 
        selectedProduct={selectedProduct}
        searchQuery=""
      />
    </div>
  );
}