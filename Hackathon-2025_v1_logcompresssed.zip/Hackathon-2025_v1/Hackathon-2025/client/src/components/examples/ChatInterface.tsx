import { useState } from "react";
import { ChatInterface } from "../ChatInterface";

export default function ChatInterfaceExample() {
  const [selectedProduct] = useState("insurance-core");

  const handleLogQuery = (query: string, productId?: string) => {
    console.log(`Log query: "${query}" for product: ${productId}`);
  };

  return (
    <div className="h-96 w-full max-w-md">
      <ChatInterface 
        selectedProduct={selectedProduct}
        onLogQuery={handleLogQuery}
      />
    </div>
  );
}