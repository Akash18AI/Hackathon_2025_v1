import { useState } from "react";
import { PlaybookExecutor } from "../PlaybookExecutor";

const mockExecution = {
  id: "exec-001",
  playbookId: "restart-services",
  playbookName: "Restart Application Services", 
  status: "running" as const,
  progress: 65,
  startTime: new Date(),
  totalSteps: 6,
  steps: [
    {
      id: "step-1",
      name: "Backup current configuration",
      status: "completed" as const,
      output: "Configuration backed up successfully",
      duration: 5,
      startTime: new Date()
    },
    {
      id: "step-2", 
      name: "Stop application services",
      status: "completed" as const,
      output: "Services stopped: app-server, web-server",
      duration: 8
    },
    {
      id: "step-3",
      name: "Update service configurations", 
      status: "completed" as const,
      duration: 12
    },
    {
      id: "step-4",
      name: "Restart services",
      status: "running" as const,
      startTime: new Date()
    },
    {
      id: "step-5",
      name: "Health check verification",
      status: "pending" as const
    },
    {
      id: "step-6", 
      name: "Update load balancer",
      status: "pending" as const
    }
  ]
}; // todo: remove mock functionality

export default function PlaybookExecutorExample() {
  const handlePause = () => {
    console.log("Pausing execution");
  };

  const handleResume = () => {
    console.log("Resuming execution"); 
  };

  const handleCancel = () => {
    console.log("Cancelling execution");
  };

  return (
    <div className="h-96 w-full max-w-2xl">
      <PlaybookExecutor 
        execution={mockExecution}
        onPause={handlePause}
        onResume={handleResume}
        onCancel={handleCancel}
      />
    </div>
  );
}