import { useState } from "react";
import { AppSidebar } from "../AppSidebar";
import { ThemeProvider } from "../ThemeProvider";
import { SidebarProvider } from "@/components/ui/sidebar";
import type { Product } from "../ProductSelector";

const mockProducts: Product[] = [
  {
    id: "insurance-core",
    name: "Insurance Core Platform",
    description: "Core insurance processing and policy management system",
    servers: [
      { id: "core-app-01", name: "Core Application Server 1", type: "app", status: "online" },
      { id: "core-web-01", name: "Core Web Server 1", type: "web", status: "online" },
      { id: "core-db-01", name: "Core Database Server", type: "database", status: "warning" },
      { id: "core-rsp-01", name: "Core RSP Server", type: "rsp", status: "online" }
    ]
  },
  {
    id: "claims-processing", 
    name: "Claims Processing System",
    description: "Automated claims processing and workflow management",
    servers: [
      { id: "claims-app-01", name: "Claims App Server 1", type: "app", status: "online" },
      { id: "claims-app-02", name: "Claims App Server 2", type: "app", status: "error" },
      { id: "claims-web-01", name: "Claims Web Server", type: "web", status: "online" },
      { id: "claims-db-01", name: "Claims Database", type: "database", status: "online" }
    ]
  }
]; // todo: remove mock functionality

const style = {
  "--sidebar-width": "20rem",
  "--sidebar-width-icon": "4rem",
};

export default function AppSidebarExample() {
  const [selectedProduct, setSelectedProduct] = useState<string>();

  return (
    <ThemeProvider>
      <SidebarProvider style={style as React.CSSProperties}>
        <div className="flex h-screen w-full">
          <AppSidebar 
            products={mockProducts}
            selectedProduct={selectedProduct}
            onProductSelect={setSelectedProduct}
          />
          <div className="flex-1 p-6">
            <h1 className="text-2xl font-bold">Main Content Area</h1>
            <p className="text-muted-foreground">This is where the main dashboard content would go.</p>
          </div>
        </div>
      </SidebarProvider>
    </ThemeProvider>
  );
}