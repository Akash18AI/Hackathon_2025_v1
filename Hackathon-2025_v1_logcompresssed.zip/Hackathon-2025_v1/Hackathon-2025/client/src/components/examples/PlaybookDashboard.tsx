import { useState } from "react";
import { PlaybookDashboard, type Playbook } from "../PlaybookDashboard";

const mockPlaybooks: Playbook[] = [
  {
    id: "restart-services",
    name: "Restart Application Services",
    description: "Gracefully restart all application services with health checks",
    category: "application",
    difficulty: "low",
    estimatedTime: "5 minutes",
    lastRun: new Date("2024-09-15"),
    successRate: 98,
    tags: ["restart", "health-check", "zero-downtime"]
  },
  {
    id: "db-connection-fix",
    name: "Database Connection Pool Reset",
    description: "Reset database connection pools and clear stale connections",
    category: "database", 
    difficulty: "medium",
    estimatedTime: "10 minutes",
    lastRun: new Date("2024-09-14"),
    successRate: 92,
    tags: ["database", "connection-pool", "performance"]
  },
  {
    id: "disk-cleanup",
    name: "System Disk Cleanup",
    description: "Clean temporary files, logs, and free up disk space",
    category: "system",
    difficulty: "low", 
    estimatedTime: "15 minutes",
    successRate: 95,
    tags: ["cleanup", "disk-space", "maintenance"]
  },
  {
    id: "network-diagnostics",
    name: "Network Connectivity Diagnostics",
    description: "Run comprehensive network tests and generate connectivity report",
    category: "networking",
    difficulty: "medium",
    estimatedTime: "8 minutes",
    successRate: 88,
    tags: ["network", "diagnostics", "connectivity"]
  },
  {
    id: "security-patch",
    name: "Apply Security Updates",
    description: "Apply critical security patches and restart affected services",
    category: "system",
    difficulty: "high",
    estimatedTime: "30 minutes", 
    lastRun: new Date("2024-09-10"),
    successRate: 85,
    tags: ["security", "patches", "updates", "critical"]
  }
]; // todo: remove mock functionality

export default function PlaybookDashboardExample() {
  const handleExecutePlaybook = (playbookId: string) => {
    console.log(`Executing playbook: ${playbookId}`);
  };

  return (
    <div className="h-96 w-full max-w-2xl">
      <PlaybookDashboard 
        playbooks={mockPlaybooks}
        onExecutePlaybook={handleExecutePlaybook}
      />
    </div>
  );
}