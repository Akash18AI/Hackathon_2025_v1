import { StatusIndicator } from "../StatusIndicator";

export default function StatusIndicatorExample() {
  return (
    <div className="p-4 space-y-4">
      <div className="space-y-2">
        <h3 className="font-medium">Status Indicators</h3>
        <div className="flex items-center gap-4">
          <StatusIndicator status="online" showText />
          <StatusIndicator status="warning" showText />
          <StatusIndicator status="error" showText />
          <StatusIndicator status="maintenance" showText />
        </div>
      </div>
      
      <div className="space-y-2">
        <h3 className="font-medium">Icon Only</h3>
        <div className="flex items-center gap-4">
          <StatusIndicator status="online" />
          <StatusIndicator status="warning" />
          <StatusIndicator status="error" />
          <StatusIndicator status="maintenance" />
        </div>
      </div>
    </div>
  );
}