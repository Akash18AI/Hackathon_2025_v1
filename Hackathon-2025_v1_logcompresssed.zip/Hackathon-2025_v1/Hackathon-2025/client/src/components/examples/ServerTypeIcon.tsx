import { ServerTypeIcon } from "../ServerTypeIcon";

export default function ServerTypeIconExample() {
  return (
    <div className="p-4 space-y-4">
      <div className="space-y-2">
        <h3 className="font-medium">Server Type Icons</h3>
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <ServerTypeIcon type="app" />
            <span className="text-sm">Application</span>
          </div>
          <div className="flex items-center gap-2">
            <ServerTypeIcon type="web" />
            <span className="text-sm">Web</span>
          </div>
          <div className="flex items-center gap-2">
            <ServerTypeIcon type="database" />
            <span className="text-sm">Database</span>
          </div>
          <div className="flex items-center gap-2">
            <ServerTypeIcon type="rsp" />
            <span className="text-sm">RSP</span>
          </div>
        </div>
      </div>
      
      <div className="space-y-2">
        <h3 className="font-medium">Different Sizes</h3>
        <div className="flex items-center gap-4">
          <ServerTypeIcon type="app" size={12} />
          <ServerTypeIcon type="web" size={16} />
          <ServerTypeIcon type="database" size={20} />
          <ServerTypeIcon type="rsp" size={24} />
        </div>
      </div>
    </div>
  );
}