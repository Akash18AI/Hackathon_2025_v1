import { useState } from "react";
import { ChevronDown, Building2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { StatusIndicator } from "./StatusIndicator";
import { ServerTypeIcon } from "./ServerTypeIcon";

export interface Server {
  id: string;
  name: string;
  type: "app" | "web" | "database" | "rsp" | "apppool";
  status: "online" | "warning" | "error" | "maintenance";
  ipAddress?: string;
}

export interface Environment {
  id: string;
  name: string;
  type: "Test" | "PreProd" | "Prod";
  servers: Server[];
  logPath: string;
}

export interface Client {
  id: string;
  name: string;
  environments: Environment[];
}

export interface Product {
  id: string;
  name: string;
  description: string;
  clients: Client[];
}

interface ProductSelectorProps {
  products: Product[];
  selectedProduct?: string;
  selectedClient?: string;
  selectedEnvironment?: string;
  userRole?: "admin" | "client";
  userClientId?: string;
  onSelectionChange: (selection: {
    productId?: string;
    clientId?: string;
    environmentId?: string;
  }) => void;
}

export function ProductSelector({ 
  products, 
  selectedProduct,
  selectedClient,
  selectedEnvironment,
  userRole = "admin",
  userClientId,
  onSelectionChange 
}: ProductSelectorProps) {
  const [expandedProducts, setExpandedProducts] = useState<Set<string>>(new Set());
  const [expandedClients, setExpandedClients] = useState<Set<string>>(new Set());

  const toggleExpandedProduct = (productId: string) => {
    const newExpanded = new Set(expandedProducts);
    if (newExpanded.has(productId)) {
      newExpanded.delete(productId);
    } else {
      newExpanded.add(productId);
    }
    setExpandedProducts(newExpanded);
  };

  const toggleExpandedClient = (clientId: string) => {
    const newExpanded = new Set(expandedClients);
    if (newExpanded.has(clientId)) {
      newExpanded.delete(clientId);
    } else {
      newExpanded.add(clientId);
    }
    setExpandedClients(newExpanded);
  };

  const handleProductClick = (productId: string) => {
    console.log(`Product selected: ${productId}`);
    onSelectionChange({ productId });
    if (!expandedProducts.has(productId)) {
      toggleExpandedProduct(productId);
    }
  };

  const handleClientClick = (productId: string, clientId: string) => {
    console.log(`Client selected: ${clientId} for product: ${productId}`);
    onSelectionChange({ productId, clientId });
    if (!expandedClients.has(clientId)) {
      toggleExpandedClient(clientId);
    }
  };

  const handleEnvironmentClick = (productId: string, clientId: string, environmentId: string) => {
    console.log(`Environment selected: ${environmentId} for client: ${clientId}, product: ${productId}`);
    onSelectionChange({ productId, clientId, environmentId });
  };

  // Filter products based on user role
  const filteredProducts = userRole === "client" && userClientId 
    ? products.map(product => ({
        ...product,
        clients: (product.clients || []).filter(client => client.id === userClientId)
      })).filter(product => (product.clients || []).length > 0)
    : products;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 px-1">
        <Building2 className="h-4 w-4 text-muted-foreground" />
        <h3 className="font-medium text-sm">Products</h3>
      </div>
      
      {filteredProducts.map((product) => {
        const isProductExpanded = expandedProducts.has(product.id);
        const totalServers = (product.clients || []).reduce((acc, client) => 
          acc + (client.environments || []).reduce((envAcc, env) => envAcc + (env.servers || []).length, 0), 0);
        const healthyServers = (product.clients || []).reduce((acc, client) => 
          acc + (client.environments || []).reduce((envAcc, env) => 
            envAcc + (env.servers || []).filter(s => s.status === "online").length, 0), 0);
        
        return (
          <Card 
            key={product.id} 
            className={selectedProduct === product.id ? "ring-2 ring-primary" : ""}
          >
            <Collapsible open={isProductExpanded} onOpenChange={() => toggleExpandedProduct(product.id)}>
              <CollapsibleTrigger asChild>
                <CardContent className="p-4">
                  <Button
                    variant="ghost"
                    className="w-full justify-between p-0 h-auto hover-elevate"
                    onClick={() => handleProductClick(product.id)}
                    data-testid={`button-select-product-${product.id}`}
                  >
                    <div className="flex items-start gap-3 text-left">
                      <div className="flex-1 space-y-2">
                        <div className="font-medium text-sm">{product.name}</div>
                        <div className="text-xs text-muted-foreground">
                          {product.description}
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-xs">
                            {(product.clients || []).length} client{(product.clients || []).length !== 1 ? "s" : ""}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {healthyServers}/{totalServers} servers
                          </Badge>
                          <StatusIndicator 
                            status={healthyServers === totalServers ? "online" : "warning"}
                          />
                        </div>
                      </div>
                    </div>
                    <ChevronDown className={`h-4 w-4 transition-transform ${isProductExpanded ? "rotate-180" : ""}`} />
                  </Button>
                </CardContent>
              </CollapsibleTrigger>
              
              <CollapsibleContent>
                <div className="px-4 pb-4 space-y-3">
                  {(product.clients || []).map((client) => {
                    const isClientExpanded = expandedClients.has(client.id);
                    const clientServers = (client.environments || []).reduce((acc, env) => acc + (env.servers || []).length, 0);
                    const clientHealthyServers = (client.environments || []).reduce((acc, env) => 
                      acc + (env.servers || []).filter(s => s.status === "online").length, 0);
                    
                    return (
                      <Card key={client.id} className={selectedClient === client.id ? "ring-1 ring-primary/50" : ""}>
                        <Collapsible open={isClientExpanded} onOpenChange={() => toggleExpandedClient(client.id)}>
                          <CollapsibleTrigger asChild>
                            <CardContent className="p-3">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="w-full justify-between p-0 h-auto hover-elevate"
                                onClick={() => handleClientClick(product.id, client.id)}
                                data-testid={`button-select-client-${client.id}`}
                              >
                                <div className="flex items-center gap-2 text-left">
                                  <Building2 className="h-4 w-4 text-muted-foreground" />
                                  <div>
                                    <div className="font-medium text-sm">{client.name}</div>
                                    <div className="text-xs text-muted-foreground">
                                      {(client.environments || []).length} environment{(client.environments || []).length !== 1 ? "s" : ""} • {clientHealthyServers}/{clientServers} servers
                                    </div>
                                  </div>
                                </div>
                                <ChevronDown className={`h-3 w-3 transition-transform ${isClientExpanded ? "rotate-180" : ""}`} />
                              </Button>
                            </CardContent>
                          </CollapsibleTrigger>
                          
                          <CollapsibleContent>
                            <div className="px-3 pb-3 space-y-2">
                              {(client.environments || []).map((environment) => {
                                const envHealthyServers = (environment.servers || []).filter(s => s.status === "online").length;
                                const isEnvSelected = selectedEnvironment === environment.id;
                                
                                return (
                                  <div 
                                    key={environment.id}
                                    className={`p-2 rounded-md cursor-pointer hover-elevate ${
                                      isEnvSelected ? "bg-primary/10 ring-1 ring-primary/30" : "bg-muted/30"
                                    }`}
                                    onClick={() => handleEnvironmentClick(product.id, client.id, environment.id)}
                                    data-testid={`button-select-environment-${environment.id}`}
                                  >
                                    <div className="flex items-center justify-between">
                                      <div className="flex items-center gap-2">
                                        <div className={`w-2 h-2 rounded-full ${
                                          environment.type === "Prod" ? "bg-red-400" :
                                          environment.type === "PreProd" ? "bg-yellow-400" : "bg-blue-400"
                                        }`} />
                                        <span className="text-sm font-medium">{environment.name}</span>
                                        <Badge variant="outline" className="text-xs">
                                          {environment.type}
                                        </Badge>
                                      </div>
                                      <div className="flex items-center gap-1">
                                        <span className="text-xs text-muted-foreground">
                                          {envHealthyServers}/{(environment.servers || []).length}
                                        </span>
                                        <StatusIndicator 
                                          status={envHealthyServers === (environment.servers || []).length ? "online" : "warning"}
                                        />
                                      </div>
                                    </div>
                                    
                                    {isEnvSelected && (environment.servers || []).length > 0 && (
                                      <div className="mt-2 space-y-1">
                                        <div className="text-xs text-muted-foreground">Servers:</div>
                                        {(environment.servers || []).map((server) => (
                                          <div 
                                            key={server.id}
                                            className="flex items-center gap-2 text-xs p-1"
                                            data-testid={`server-${server.id}`}
                                          >
                                            <ServerTypeIcon type={server.type} size={12} />
                                            <span className="flex-1">{server.name}</span>
                                            {server.ipAddress && (
                                              <span className="text-muted-foreground font-mono">{server.ipAddress}</span>
                                            )}
                                            <StatusIndicator status={server.status} />
                                          </div>
                                        ))}
                                      </div>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          </CollapsibleContent>
                        </Collapsible>
                      </Card>
                    );
                  })}
                </div>
              </CollapsibleContent>
            </Collapsible>
          </Card>
        );
      })}
    </div>
  );
}