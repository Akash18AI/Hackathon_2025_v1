import { useState, useEffect } from "react";
import { Play, Pause, Square, CheckCircle, AlertCircle, Clock, Terminal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface ExecutionStep {
  id: string;
  name: string;
  status: "pending" | "running" | "completed" | "failed" | "skipped";
  output?: string;
  duration?: number;
  startTime?: Date;
}

interface PlaybookExecution {
  id: string;
  playbookId: string;
  playbookName: string;
  status: "running" | "completed" | "failed" | "paused" | "cancelled";
  progress: number;
  startTime: Date;
  endTime?: Date;
  steps: ExecutionStep[];
  totalSteps: number;
}

interface PlaybookExecutorProps {
  execution?: PlaybookExecution;
  onPause?: () => void;
  onResume?: () => void;
  onCancel?: () => void;
}

const stepStatusConfig = {
  pending: { icon: Clock, color: "text-muted-foreground" },
  running: { icon: Play, color: "text-blue-500" },
  completed: { icon: CheckCircle, color: "text-green-500" },
  failed: { icon: AlertCircle, color: "text-red-500" },
  skipped: { icon: Square, color: "text-yellow-500" },
};

export function PlaybookExecutor({ 
  execution, 
  onPause, 
  onResume, 
  onCancel 
}: PlaybookExecutorProps) {
  const [liveOutput, setLiveOutput] = useState<string[]>([]);

  useEffect(() => {
    if (execution?.status === "running") {
      // Simulate live output updates
      const interval = setInterval(() => {
        const outputs = [
          "[INFO] Connecting to target servers...",
          "[INFO] Checking system prerequisites...",
          "[INFO] Backing up configuration files...",
          "[WARN] High memory usage detected on app-server-01",
          "[INFO] Executing service restart sequence...",
          "[INFO] Waiting for services to stabilize...",
          "[INFO] Running post-execution health checks...",
        ];
        
        setLiveOutput(prev => {
          if (prev.length < outputs.length) {
            return [...prev, outputs[prev.length]];
          }
          return prev;
        });
      }, 1500);

      return () => clearInterval(interval);
    }
  }, [execution?.status]);

  const handleAction = (action: string) => {
    console.log(`Playbook execution action: ${action}`);
    switch (action) {
      case "pause":
        onPause?.();
        break;
      case "resume":
        onResume?.();
        break;
      case "cancel":
        onCancel?.();
        break;
    }
  };

  if (!execution) {
    return (
      <Card className="h-full flex items-center justify-center">
        <CardContent className="text-center text-muted-foreground">
          <Terminal className="h-12 w-12 mx-auto mb-4 opacity-50" />
          <p className="text-sm">No playbook execution in progress</p>
          <p className="text-xs mt-2">Select and execute a playbook to see real-time progress</p>
        </CardContent>
      </Card>
    );
  }

  const completedSteps = execution.steps.filter(step => step.status === "completed").length;
  const failedSteps = execution.steps.filter(step => step.status === "failed").length;
  const runningStep = execution.steps.find(step => step.status === "running");

  return (
    <Card className="flex flex-col h-full">
      <CardHeader className="flex-shrink-0">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Terminal className="h-5 w-5" />
            Playbook Execution
          </CardTitle>
          <div className="flex items-center gap-2">
            {execution.status === "running" && (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleAction("pause")}
                  data-testid="button-pause-execution"
                >
                  <Pause className="h-4 w-4" />
                </Button>
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => handleAction("cancel")}
                  data-testid="button-cancel-execution"
                >
                  <Square className="h-4 w-4" />
                </Button>
              </>
            )}
            {execution.status === "paused" && (
              <Button
                variant="default"
                size="sm"
                onClick={() => handleAction("resume")}
                data-testid="button-resume-execution"
              >
                <Play className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
        
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Badge variant="outline">{execution.playbookName}</Badge>
            <Badge 
              variant={execution.status === "failed" ? "destructive" : 
                      execution.status === "completed" ? "default" : "secondary"}
            >
              {execution.status}
            </Badge>
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Progress: {completedSteps}/{execution.totalSteps} steps</span>
              <span>{execution.progress}%</span>
            </div>
            <Progress value={execution.progress} className="w-full" />
          </div>

          {failedSteps > 0 && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                {failedSteps} step{failedSteps > 1 ? "s" : ""} failed. Check the execution log for details.
              </AlertDescription>
            </Alert>
          )}
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col gap-4 p-0">
        <div className="flex-shrink-0 px-6">
          <h4 className="font-medium text-sm mb-3">Execution Steps</h4>
          <div className="space-y-2">
            {execution.steps.map((step, index) => {
              const config = stepStatusConfig[step.status];
              const Icon = config.icon;
              
              return (
                <div
                  key={step.id}
                  className={`flex items-center gap-3 p-2 rounded-lg ${
                    step.status === "running" ? "bg-primary/10 ring-1 ring-primary/20" : ""
                  }`}
                  data-testid={`step-${step.id}`}
                >
                  <div className="flex-shrink-0">
                    <Icon className={`h-4 w-4 ${config.color} ${
                      step.status === "running" ? "animate-spin" : ""
                    }`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">
                        {index + 1}. {step.name}
                      </span>
                      {step.duration && (
                        <span className="text-xs text-muted-foreground">
                          ({step.duration}s)
                        </span>
                      )}
                    </div>
                    {step.output && (
                      <p className="text-xs text-muted-foreground mt-1 font-mono">
                        {step.output}
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="flex-1 px-6">
          <h4 className="font-medium text-sm mb-3">Live Output</h4>
          <ScrollArea className="h-40 rounded-md border bg-muted/50 p-3" data-testid="execution-output">
            <div className="space-y-1 font-mono text-xs">
              {liveOutput.length === 0 ? (
                <p className="text-muted-foreground">Waiting for execution output...</p>
              ) : (
                liveOutput.map((line, index) => (
                  <div key={index} className="flex gap-2">
                    <span className="text-muted-foreground">
                      {new Date().toLocaleTimeString()}
                    </span>
                    <span>{line}</span>
                  </div>
                ))
              )}
            </div>
          </ScrollArea>
        </div>
      </CardContent>
    </Card>
  );
}