import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Wand2, Send, Save, Code, Play, AlertCircle, CheckCircle2, Clock } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface GeneratedPlaybook {
  id: string;
  name: string;
  description: string;
  category: string;
  yaml: string;
  estimatedTime: string;
  tags: string[];
  variables?: { name: string; description: string; default?: string }[];
}

interface PlaybookCreatorProps {
  selectedProduct?: string;
  selectedClient?: string;
  selectedEnvironment?: string;
  onSavePlaybook?: (playbook: GeneratedPlaybook) => void;
}

export function PlaybookCreator({ 
  selectedProduct, 
  selectedClient, 
  selectedEnvironment,
  onSavePlaybook 
}: PlaybookCreatorProps) {
  const [prompt, setPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedPlaybook, setGeneratedPlaybook] = useState<GeneratedPlaybook | null>(null);
  const [playbookName, setPlaybookName] = useState("");
  const [playbookCategory, setPlaybookCategory] = useState("application");
  const [customYaml, setCustomYaml] = useState("");

  // Mock AI generation - in real app this would call your OpenAI integration
  const generatePlaybook = async () => {
    if (!prompt.trim()) return;
    
    setIsGenerating(true);
    
    // Simulate AI processing time
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Mock generated playbook based on prompt
    const mockPlaybook: GeneratedPlaybook = {
      id: `generated-${Date.now()}`,
      name: `${prompt.substring(0, 50)}...`,
      description: `Automated playbook to ${prompt.toLowerCase()}`,
      category: playbookCategory,
      estimatedTime: "5-10 minutes",
      tags: ["custom", "ai-generated", playbookCategory],
      yaml: `---
- name: ${prompt}
  hosts: ${selectedEnvironment || 'all'}
  become: yes
  vars:
    target_service: "{{ service_name | default('app-service') }}"
    backup_location: "/var/backups"
  
  tasks:
    - name: Check current service status
      systemd:
        name: "{{ target_service }}"
        state: started
      register: service_status
      
    - name: Create backup directory
      file:
        path: "{{ backup_location }}"
        state: directory
        mode: '0755'
        
    - name: Stop service gracefully
      systemd:
        name: "{{ target_service }}"
        state: stopped
      when: service_status.status.ActiveState == "active"
      
    - name: Wait for service to stop
      wait_for:
        port: 8080
        state: stopped
        timeout: 60
        
    - name: Perform maintenance task
      shell: |
        # Add your custom maintenance commands here
        echo "Performing maintenance on {{ target_service }}"
        # Example: Clear cache, rotate logs, etc.
        
    - name: Start service
      systemd:
        name: "{{ target_service }}"
        state: started
        enabled: yes
        
    - name: Verify service is running
      uri:
        url: "http://localhost:8080/health"
        method: GET
        status_code: 200
      retries: 3
      delay: 10
      register: health_check
      
    - name: Report completion
      debug:
        msg: "Successfully completed maintenance for {{ target_service }}. Health check: {{ health_check.status }}"`,
      variables: [
        { name: "service_name", description: "Name of the service to manage", default: "app-service" },
        { name: "backup_location", description: "Directory to store backups", default: "/var/backups" }
      ]
    };
    
    setGeneratedPlaybook(mockPlaybook);
    setCustomYaml(mockPlaybook.yaml);
    setPlaybookName(mockPlaybook.name);
    setIsGenerating(false);
  };

  const handleSavePlaybook = () => {
    if (!generatedPlaybook) return;
    
    const finalPlaybook: GeneratedPlaybook = {
      ...generatedPlaybook,
      name: playbookName || generatedPlaybook.name,
      category: playbookCategory,
      yaml: customYaml
    };
    
    onSavePlaybook?.(finalPlaybook);
    
    // Reset form
    setPrompt("");
    setGeneratedPlaybook(null);
    setCustomYaml("");
    setPlaybookName("");
  };

  const examplePrompts = [
    "Restart Apache web server and check health status",
    "Clean up old log files older than 30 days and compress them",
    "Update system packages and reboot if required",
    "Deploy new application version with rollback capability", 
    "Monitor disk space and send alerts if above 85%",
    "Backup database and verify backup integrity"
  ];

  return (
    <Card className="flex flex-col h-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Wand2 className="h-5 w-5" />
          AI Playbook Creator
        </CardTitle>
        <CardDescription>
          Describe your automation task in natural language and let AI generate an Ansible playbook
        </CardDescription>
        {selectedProduct && selectedClient && selectedEnvironment && (
          <Badge variant="outline" className="w-fit">
            Target: {selectedProduct} • {selectedClient} • {selectedEnvironment}
          </Badge>
        )}
      </CardHeader>
      
      <CardContent className="flex-1 flex flex-col gap-4 p-4">
        {!generatedPlaybook ? (
          // Playbook Generation Phase
          <div className="space-y-4">
            {/* Example Prompts */}
            <div>
              <label className="text-sm font-medium mb-2 block">Quick Examples:</label>
              <div className="flex flex-wrap gap-2">
                {examplePrompts.map((example, index) => (
                  <Badge
                    key={index}
                    variant="secondary"
                    className="cursor-pointer hover-elevate text-xs"
                    onClick={() => setPrompt(example)}
                    data-testid={`example-prompt-${index}`}
                  >
                    {example}
                  </Badge>
                ))}
              </div>
            </div>
            
            {/* Category Selection */}
            <div>
              <label className="text-sm font-medium mb-2 block">Playbook Category:</label>
              <Select value={playbookCategory} onValueChange={setPlaybookCategory}>
                <SelectTrigger data-testid="select-category">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="application">Application Management</SelectItem>
                  <SelectItem value="system">System Operations</SelectItem>
                  <SelectItem value="database">Database Operations</SelectItem>
                  <SelectItem value="networking">Network Management</SelectItem>
                  <SelectItem value="security">Security & Compliance</SelectItem>
                  <SelectItem value="monitoring">Monitoring & Alerting</SelectItem>
                  <SelectItem value="backup">Backup & Recovery</SelectItem>
                  <SelectItem value="deployment">Deployment & CI/CD</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {/* Prompt Input */}
            <div>
              <label className="text-sm font-medium mb-2 block">Describe your automation task:</label>
              <Textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Example: I need to restart the Apache web server, check if it's responding on port 80, and send a notification when complete..."
                className="min-h-24"
                data-testid="textarea-prompt"
              />
            </div>
            
            {!selectedProduct || !selectedClient || !selectedEnvironment ? (
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Select a product, client, and environment from the sidebar to target your playbook.
                </AlertDescription>
              </Alert>
            ) : null}
            
            <Button
              onClick={generatePlaybook}
              disabled={!prompt.trim() || isGenerating || !selectedProduct || !selectedClient || !selectedEnvironment}
              className="w-full"
              data-testid="button-generate-playbook"
            >
              {isGenerating ? (
                <>
                  <Clock className="h-4 w-4 mr-2 animate-spin" />
                  Generating Playbook...
                </>
              ) : (
                <>
                  <Wand2 className="h-4 w-4 mr-2" />
                  Generate Ansible Playbook
                </>
              )}
            </Button>
          </div>
        ) : (
          // Playbook Review & Edit Phase
          <div className="space-y-4 flex-1 flex flex-col">
            <div className="flex items-center justify-between">
              <Alert>
                <CheckCircle2 className="h-4 w-4" />
                <AlertDescription>
                  Playbook generated successfully! Review and customize as needed.
                </AlertDescription>
              </Alert>
            </div>
            
            <Tabs defaultValue="preview" className="flex-1 flex flex-col">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="preview" data-testid="tab-preview">Preview</TabsTrigger>
                <TabsTrigger value="edit" data-testid="tab-edit">Edit YAML</TabsTrigger>
                <TabsTrigger value="variables" data-testid="tab-variables">Variables</TabsTrigger>
              </TabsList>
              
              <TabsContent value="preview" className="flex-1 flex flex-col space-y-4">
                <div className="grid grid-cols-1 gap-2">
                  <div>
                    <label className="text-sm font-medium mb-1 block">Playbook Name:</label>
                    <Input
                      value={playbookName}
                      onChange={(e) => setPlaybookName(e.target.value)}
                      placeholder="Enter playbook name..."
                      data-testid="input-playbook-name"
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium mb-1 block">Category:</label>
                    <Select value={playbookCategory} onValueChange={setPlaybookCategory}>
                      <SelectTrigger data-testid="select-category-edit">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="application">Application</SelectItem>
                        <SelectItem value="system">System</SelectItem>
                        <SelectItem value="database">Database</SelectItem>
                        <SelectItem value="networking">Networking</SelectItem>
                        <SelectItem value="security">Security</SelectItem>
                        <SelectItem value="monitoring">Monitoring</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-2 block">Generated Tasks:</label>
                  <ScrollArea className="h-40 rounded border p-3 bg-muted/50">
                    <pre className="text-sm text-muted-foreground">
                      {generatedPlaybook.yaml.split('\n').filter(line => line.includes('name:')).join('\n')}
                    </pre>
                  </ScrollArea>
                </div>
              </TabsContent>
              
              <TabsContent value="edit" className="flex-1 flex flex-col">
                <div className="flex-1">
                  <label className="text-sm font-medium mb-2 block">YAML Content:</label>
                  <Textarea
                    value={customYaml}
                    onChange={(e) => setCustomYaml(e.target.value)}
                    className="font-mono text-sm min-h-60"
                    data-testid="textarea-yaml-editor"
                  />
                </div>
              </TabsContent>
              
              <TabsContent value="variables" className="flex-1 flex flex-col">
                <div>
                  <label className="text-sm font-medium mb-2 block">Playbook Variables:</label>
                  <div className="space-y-2">
                    {generatedPlaybook.variables?.map((variable, index) => (
                      <div key={index} className="border rounded p-3 bg-muted/30">
                        <div className="font-medium text-sm">{variable.name}</div>
                        <div className="text-xs text-muted-foreground">{variable.description}</div>
                        {variable.default && (
                          <div className="text-xs text-blue-600">Default: {variable.default}</div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
            </Tabs>
            
            <div className="flex gap-2 pt-4 border-t">
              <Button
                variant="outline"
                onClick={() => setGeneratedPlaybook(null)}
                data-testid="button-back"
              >
                Back to Generator
              </Button>
              <Button
                onClick={handleSavePlaybook}
                className="flex-1"
                data-testid="button-save-playbook"
              >
                <Save className="h-4 w-4 mr-2" />
                Save Playbook
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}