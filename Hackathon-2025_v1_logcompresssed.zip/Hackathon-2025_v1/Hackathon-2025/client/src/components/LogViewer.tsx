import { useState, useEffect } from "react";
import { Search, Download, RefreshCw, Filter, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface LogEntry {
  id: string;
  timestamp: string;
  level: "INFO" | "WARN" | "ERROR" | "DEBUG";
  service: string;
  message: string;
  details?: string;
}

interface LogViewerProps {
  selectedProduct?: string;
  selectedClient?: string;
  selectedEnvironment?: string;
  searchQuery?: string;
}

const logLevelColors = {
  INFO: "text-blue-400",
  WARN: "text-yellow-400", 
  ERROR: "text-red-400",
  DEBUG: "text-gray-400",
};

export function LogViewer({ 
  selectedProduct, 
  selectedClient, 
  selectedEnvironment, 
  searchQuery 
}: LogViewerProps) {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [filteredLogs, setFilteredLogs] = useState<LogEntry[]>([]);
  const [searchTerm, setSearchTerm] = useState(searchQuery || "");
  const [selectedLevel, setSelectedLevel] = useState<string>("all");
  const [selectedService, setSelectedService] = useState<string>("all");
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchLogs = async () => {
    if (!selectedProduct || !selectedClient || !selectedEnvironment) {
      setLogs([]);
      setError(null);
      return;
    }

    setIsRefreshing(true);
    setError(null);
    try {
      const response = await fetch(`/api/logs/${selectedProduct}/${selectedClient}/${selectedEnvironment}`);
      const data = await response.json();
      
      if (!response.ok) {
        setError(`Failed to fetch logs: ${data.error || response.statusText}`);
        setLogs([]);
        return;
      }
      
      if (data.logs && data.logs.length > 0) {
        setLogs(data.logs);
        setError(null);
      } else {
        setError(data.error || "No logs found for this environment");
        setLogs([]);
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error occurred";
      setError(`Error fetching logs: ${errorMessage}`);
      setLogs([]);
    } finally {
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, [selectedProduct, selectedClient, selectedEnvironment]);

  useEffect(() => {
    // Apply filters
    let filtered = logs;
    
    if (searchTerm) {
      filtered = filtered.filter(log => 
        log.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.service.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (log.details && log.details.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }
    
    if (selectedLevel !== "all") {
      filtered = filtered.filter(log => log.level === selectedLevel);
    }
    
    if (selectedService !== "all") {
      filtered = filtered.filter(log => log.service === selectedService);
    }
    
    setFilteredLogs(filtered);
  }, [logs, searchTerm, selectedLevel, selectedService]);

  useEffect(() => {
    if (searchQuery) {
      setSearchTerm(searchQuery);
    }
  }, [searchQuery]);

  const handleRefresh = () => {
    console.log(`Refreshing logs for product: ${selectedProduct}`);
    fetchLogs();
  };

  const handleExport = () => {
    console.log(`Exporting ${filteredLogs.length} log entries`);
  };

  const services = Array.from(new Set(logs.map(log => log.service)));
  const errorCount = logs.filter(log => log.level === "ERROR").length;
  const warnCount = logs.filter(log => log.level === "WARN").length;

  return (
    <div className="flex flex-col h-full">
      <div className="flex-shrink-0 border-b p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            <h3 className="text-lg font-semibold">Log Analysis</h3>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="destructive" className="text-xs">
              {errorCount} errors
            </Badge>
            <Badge variant="secondary" className="text-xs">
              {warnCount} warnings
            </Badge>
            <Button
              variant="outline" 
              size="sm"
              onClick={handleRefresh}
              disabled={isRefreshing}
              data-testid="button-refresh-logs"
            >
              <RefreshCw className={`h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleExport}
              data-testid="button-export-logs"
            >
              <Download className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
      
      <div className="flex-shrink-0 p-6 border-b space-y-4">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search logs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
              data-testid="input-log-search"
            />
          </div>
          <Select value={selectedLevel} onValueChange={setSelectedLevel}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Levels</SelectItem>
              <SelectItem value="ERROR">Error</SelectItem>
              <SelectItem value="WARN">Warning</SelectItem>
              <SelectItem value="INFO">Info</SelectItem>
              <SelectItem value="DEBUG">Debug</SelectItem>
            </SelectContent>
          </Select>
          <Select value={selectedService} onValueChange={setSelectedService}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Services</SelectItem>
              {services.map(service => (
                <SelectItem key={service} value={service}>
                  {service}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex-1 min-h-0 relative">
        <ScrollArea className="absolute inset-0" data-testid="log-entries">
          <div className="p-6">
          {!selectedProduct || !selectedClient || !selectedEnvironment ? (
            <div className="text-center text-muted-foreground py-8">
              <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p className="text-sm">Select a product, client, and environment to view logs</p>
            </div>
          ) : error ? (
            <div className="text-center text-red-400 py-8">
              <div className="h-12 w-12 mx-auto mb-4 bg-red-100 dark:bg-red-900 rounded-full flex items-center justify-center">
                <span className="text-red-600 dark:text-red-300">⚠</span>
              </div>
              <p className="text-sm font-medium">Error loading logs</p>
              <p className="text-xs text-muted-foreground mt-1">{error}</p>
            </div>
          ) : isRefreshing ? (
            <div className="text-center text-muted-foreground py-8">
              <RefreshCw className="h-8 w-8 mx-auto mb-4 animate-spin" />
              <p className="text-sm">Loading logs...</p>
            </div>
          ) : filteredLogs.length === 0 ? (
            <div className="text-center text-muted-foreground py-8">
              <Search className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p className="text-sm">No logs match your search criteria</p>
            </div>
          ) : (
            <div className="space-y-2 pb-4">
              {filteredLogs.map((log) => (
                <Card key={log.id} className="p-3 hover-elevate">
                  <div className="flex items-start gap-3">
                    <Badge 
                      variant={log.level === "ERROR" ? "destructive" : "secondary"}
                      className="text-xs font-mono"
                    >
                      {log.level}
                    </Badge>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono text-xs text-muted-foreground">
                          {log.timestamp}
                        </span>
                        <Badge variant="outline" className="text-xs">
                          {log.service}
                        </Badge>
                      </div>
                      <p className="text-sm font-medium mb-1">{log.message}</p>
                      {log.details && (
                        <p className="text-xs text-muted-foreground font-mono bg-muted/50 p-2 rounded">
                          {log.details}
                        </p>
                      )}
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}