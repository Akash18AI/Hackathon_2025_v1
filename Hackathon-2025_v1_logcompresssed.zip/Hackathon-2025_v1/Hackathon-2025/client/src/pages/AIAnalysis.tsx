import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChatInterface } from "@/components/ChatInterface";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Brain, Zap, TrendingUp, AlertTriangle } from "lucide-react";

interface AIAnalysisProps {
  selectedProduct?: string;
  selectedClient?: string;
  selectedEnvironment?: string;
  userSession?: any;
}

export default function AIAnalysis({
  selectedProduct,
  selectedClient,
  selectedEnvironment,
  userSession
}: AIAnalysisProps) {
  const [searchQuery, setSearchQuery] = useState("");

  const handleLogQuery = (query: string, productId?: string) => {
    console.log(`AI analyzing logs: "${query}" for product: ${productId}`);
    setSearchQuery(query);
  };

  // Mock AI insights data
  const aiInsights = [
    {
      id: "1",
      type: "performance",
      title: "Performance Degradation Detected",
      description: "Response times have increased by 23% in the last 2 hours",
      severity: "warning",
      confidence: 87,
      timestamp: new Date(),
      icon: TrendingUp
    },
    {
      id: "2", 
      type: "error",
      title: "Recurring Error Pattern",
      description: "Database timeout errors appearing 5x more frequently",
      severity: "high",
      confidence: 94,
      timestamp: new Date(),
      icon: AlertTriangle
    },
    {
      id: "3",
      type: "optimization",
      title: "Resource Optimization Opportunity",
      description: "Memory usage could be optimized in Claims service",
      severity: "info",
      confidence: 76,
      timestamp: new Date(),
      icon: Zap
    }
  ];

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high": return "destructive";
      case "warning": return "secondary";
      case "info": return "outline";
      default: return "outline";
    }
  };

  return (
    <div className="flex flex-col h-full p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2" data-testid="text-page-title">
            <Brain className="h-8 w-8 text-primary" />
            AI Analysis
          </h1>
          <p className="text-muted-foreground mt-1">
            AI-powered insights and analysis for your infrastructure
          </p>
        </div>
        <Badge variant="outline" className="text-sm">
          {selectedProduct ? `Analyzing: ${selectedProduct}` : "Select a product to analyze"}
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 flex-1">
        {/* AI Chat Interface */}
        <div className="flex flex-col">
          <Card className="flex-1">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5" />
                AI Assistant
              </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 p-0">
              <div className="h-[500px]">
                <ChatInterface
                  selectedProduct={selectedProduct}
                  selectedClient={selectedClient}
                  selectedEnvironment={selectedEnvironment}
                  onLogQuery={handleLogQuery}
                />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* AI Insights */}
        <div className="flex flex-col space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Real-time Insights
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {aiInsights.map((insight) => (
                <div
                  key={insight.id}
                  className="flex items-start space-x-3 p-3 border rounded-lg hover-elevate"
                  data-testid={`card-insight-${insight.id}`}
                >
                  <insight.icon className="h-5 w-5 mt-1 text-muted-foreground" />
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium text-sm">{insight.title}</h4>
                      <Badge variant={getSeverityColor(insight.severity)} className="text-xs">
                        {insight.confidence}% confidence
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {insight.description}
                    </p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-muted-foreground">
                        {insight.timestamp.toLocaleTimeString()}
                      </span>
                      <Button variant="ghost" size="sm" data-testid={`button-investigate-${insight.id}`}>
                        Investigate
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Analysis Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button variant="outline" className="w-full justify-start" data-testid="button-analyze-logs">
                <Brain className="h-4 w-4 mr-2" />
                Analyze Recent Logs
              </Button>
              <Button variant="outline" className="w-full justify-start" data-testid="button-performance-report">
                <TrendingUp className="h-4 w-4 mr-2" />
                Generate Performance Report
              </Button>
              <Button variant="outline" className="w-full justify-start" data-testid="button-anomaly-detection">
                <AlertTriangle className="h-4 w-4 mr-2" />
                Run Anomaly Detection
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}