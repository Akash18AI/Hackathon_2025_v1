import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PlaybookDashboard, type Playbook } from "@/components/PlaybookDashboard";
import { PlaybookExecutor } from "@/components/PlaybookExecutor";
import { PlaybookCreator } from "@/components/PlaybookCreator";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BookOpen, Play, Plus, Activity } from "lucide-react";

interface PlaybooksProps {
  selectedProduct?: string;
  selectedClient?: string;
  selectedEnvironment?: string;
  userSession?: any;
}

// Mock playbooks data based on actual DevOps operations
const mockPlaybooks: Playbook[] = [
  {
    id: "service-restart",
    name: "Service Restart",
    description: "Gracefully restart specific Windows services or Linux daemons on target servers",
    category: "application",
    difficulty: "low",
    estimatedTime: "2-5 minutes",
    lastRun: new Date("2024-09-15"),
    successRate: 98,
    tags: ["service", "restart", "maintenance", "windows", "linux"]
  },
  {
    id: "process-restart",
    name: "Process Restart",
    description: "Kill and restart specific processes by name or PID across selected servers",
    category: "application",
    difficulty: "low",
    estimatedTime: "1-3 minutes",
    lastRun: new Date("2024-09-15"),
    successRate: 95,
    tags: ["process", "restart", "maintenance", "kill"]
  },
  {
    id: "apppool-stop",
    name: "Application Pool Stop",
    description: "Stop IIS Application Pool on Windows servers for maintenance",
    category: "application",
    difficulty: "low",
    estimatedTime: "1-2 minutes",
    lastRun: new Date("2024-09-15"),
    successRate: 99,
    tags: ["apppool", "iis", "stop", "windows", "maintenance"]
  },
  {
    id: "apppool-start",
    name: "Application Pool Start",
    description: "Start IIS Application Pool on Windows servers after maintenance",
    category: "application",
    difficulty: "low",
    estimatedTime: "1-2 minutes",
    lastRun: new Date("2024-09-15"),
    successRate: 99,
    tags: ["apppool", "iis", "start", "windows", "maintenance"]
  },
  {
    id: "application-restart",
    name: "Application Restart",
    description: "Full restart of Insurity applications including web services and background processes",
    category: "application",
    difficulty: "medium",
    estimatedTime: "3-8 minutes",
    lastRun: new Date("2024-09-14"),
    successRate: 92,
    tags: ["application", "restart", "full-stack", "insurity"]
  },
  {
    id: "clear-disk-space",
    name: "Clear Disk Space",
    description: "Clean up log files, temporary files, and old backups to free disk space",
    category: "system",
    difficulty: "low", 
    estimatedTime: "5-15 minutes",
    lastRun: new Date("2024-09-14"),
    successRate: 96,
    tags: ["cleanup", "disk-space", "logs", "maintenance"]
  },
  {
    id: "database-backup",
    name: "Database Backup",
    description: "Create full database backup with verification for selected environment",
    category: "database",
    difficulty: "medium",
    estimatedTime: "15-30 minutes",
    lastRun: new Date("2024-09-14"),
    successRate: 94,
    tags: ["backup", "database", "critical", "verification"]
  },
  {
    id: "log-rotation",
    name: "Log Rotation & Archive",
    description: "Rotate application logs and archive old log files to prevent disk space issues",
    category: "system",
    difficulty: "low",
    estimatedTime: "3-10 minutes",
    lastRun: new Date("2024-09-15"),
    successRate: 97,
    tags: ["logs", "rotation", "archive", "maintenance"]
  },
  {
    id: "health-check-services",
    name: "Service Health Check",
    description: "Verify all critical services are running and responding properly",
    category: "monitoring",
    difficulty: "low",
    estimatedTime: "2-5 minutes",
    lastRun: new Date("2024-09-15"),
    successRate: 99,
    tags: ["health-check", "services", "monitoring", "verification"]
  },
  {
    id: "memory-cleanup",
    name: "Memory Cleanup",
    description: "Clear memory caches and restart memory-intensive processes",
    category: "performance",
    difficulty: "medium",
    estimatedTime: "3-7 minutes",
    lastRun: new Date("2024-09-15"),
    successRate: 89,
    tags: ["memory", "performance", "cache", "cleanup"]
  }
];

export default function Playbooks({
  selectedProduct,
  selectedClient,
  selectedEnvironment,
  userSession
}: PlaybooksProps) {
  const [activeExecution, setActiveExecution] = useState();

  const handleExecutePlaybook = (playbookId: string) => {
    console.log(`Executing playbook: ${playbookId}`);
    const playbook = mockPlaybooks.find(p => p.id === playbookId);
    if (playbook) {
      setActiveExecution({
        id: `exec-${Date.now()}`,
        playbookId,
        playbookName: playbook.name,
        status: "running" as const,
        startTime: new Date(),
        progress: 0,
        currentStep: "Initializing...",
        logs: [`Starting execution of ${playbook.name}...`]
      } as any);
    }
  };

  const handleSavePlaybook = (playbook: any) => {
    console.log("Saving new playbook:", playbook);
    // In a real app, this would save to the backend
  };

  const getPlaybookStats = () => {
    const total = mockPlaybooks.length;
    const categories = Array.from(new Set(mockPlaybooks.map(p => p.category))).length;
    const avgSuccess = Math.round(
      mockPlaybooks.reduce((sum, p) => sum + p.successRate, 0) / total
    );
    return { total, categories, avgSuccess };
  };

  const stats = getPlaybookStats();

  return (
    <div className="flex flex-col h-full p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2" data-testid="text-page-title">
            <BookOpen className="h-8 w-8 text-primary" />
            Playbooks
          </h1>
          <p className="text-muted-foreground mt-1">
            Automation playbook management and execution
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-sm">
            {selectedEnvironment ? `${selectedProduct} • ${selectedEnvironment}` : "No environment selected"}
          </Badge>
          {activeExecution && (
            <Badge variant="secondary" className="text-sm flex items-center gap-1">
              <Activity className="h-3 w-3" />
              Executing
            </Badge>
          )}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Playbooks</p>
                <p className="text-2xl font-bold" data-testid="text-total-playbooks">{stats.total}</p>
              </div>
              <BookOpen className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Categories</p>
                <p className="text-2xl font-bold" data-testid="text-categories-count">{stats.categories}</p>
              </div>
              <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                <span className="text-primary font-bold text-sm">#</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Avg Success Rate</p>
                <p className="text-2xl font-bold text-green-600" data-testid="text-success-rate">{stats.avgSuccess}%</p>
              </div>
              <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
                <span className="text-green-600 font-bold">✓</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <div className="flex-1">
        <Tabs defaultValue="dashboard" className="h-full">
          <TabsList className="grid w-full grid-cols-3" data-testid="tabs-playbooks">
            <TabsTrigger value="dashboard" data-testid="tab-dashboard">
              <BookOpen className="h-4 w-4 mr-2" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="executor" data-testid="tab-executor">
              <Play className="h-4 w-4 mr-2" />
              Executor
            </TabsTrigger>
            <TabsTrigger value="creator" data-testid="tab-creator">
              <Plus className="h-4 w-4 mr-2" />
              Creator
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="mt-6 h-full">
            <Card className="h-full">
              <CardHeader>
                <CardTitle>Available Playbooks</CardTitle>
              </CardHeader>
              <CardContent className="h-full">
                <PlaybookDashboard 
                  playbooks={mockPlaybooks}
                  onExecutePlaybook={handleExecutePlaybook}
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="executor" className="mt-6 h-full">
            <Card className="h-full">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Play className="h-5 w-5" />
                  Playbook Executor
                </CardTitle>
              </CardHeader>
              <CardContent className="h-full">
                {activeExecution ? (
                  <PlaybookExecutor 
                    execution={activeExecution}
                    onPause={() => console.log("Pausing execution")}
                    onResume={() => console.log("Resuming execution")}
                    onCancel={() => {
                      console.log("Cancelling execution");
                      setActiveExecution(undefined);
                    }}
                  />
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <div className="text-center space-y-4">
                      <Play className="h-16 w-16 text-muted-foreground mx-auto" />
                      <div>
                        <h3 className="text-lg font-medium">No Active Execution</h3>
                        <p className="text-muted-foreground">
                          Select a playbook from the Dashboard to start execution
                        </p>
                      </div>
                      <Button 
                        variant="outline" 
                        onClick={() => {
                          // Switch to dashboard tab
                          const dashboardTab = document.querySelector('[data-testid="tab-dashboard"]') as HTMLElement;
                          dashboardTab?.click();
                        }}
                        data-testid="button-go-to-dashboard"
                      >
                        Go to Dashboard
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="creator" className="mt-6 h-full">
            <Card className="h-full">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Plus className="h-5 w-5" />
                  Playbook Creator
                </CardTitle>
              </CardHeader>
              <CardContent className="h-full">
                <PlaybookCreator 
                  selectedProduct={selectedProduct}
                  selectedClient={selectedClient}
                  selectedEnvironment={selectedEnvironment}
                  onSavePlaybook={handleSavePlaybook}
                />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}