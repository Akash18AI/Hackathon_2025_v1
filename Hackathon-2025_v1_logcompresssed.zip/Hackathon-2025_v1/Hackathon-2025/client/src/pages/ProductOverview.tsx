import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Server, Users, Activity } from "lucide-react";
import { useLocation } from "wouter";
import type { Product } from "@/components/ProductSelector";

interface ProductOverviewProps {
  products: Product[];
  onProductSelect: (productId: string) => void;
  userRole?: "admin" | "client";
  userClientName?: string;
  userClientId?: string;
}


export default function ProductOverview({ products, onProductSelect, userRole, userClientName, userClientId }: ProductOverviewProps) {
  const [, setLocation] = useLocation();
  const getStatusColor = (status: string) => {
    switch (status) {
      case "healthy": return "bg-green-500/10 text-green-600 border-green-500/20";
      case "warning": return "bg-yellow-500/10 text-yellow-600 border-yellow-500/20";
      case "error": return "bg-red-500/10 text-red-600 border-red-500/20";
      case "unknown": return "bg-gray-500/10 text-gray-600 border-gray-500/20";
      default: return "bg-gray-500/10 text-gray-600 border-gray-500/20";
    }
  };

  return (
    <div className="flex-1 p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2" data-testid="text-page-title">Product Overview</h1>
        <p className="text-muted-foreground">
          {userRole === "client" && userClientName 
            ? `${userClientName} products and infrastructure status`
            : "Comprehensive view of all Insurity products and their infrastructure status"
          }
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {products.map((product) => {
          // Filter clients based on user role - for client users, only show their own data
          const relevantClients = userRole === "client" && userClientId
            ? product.clients.filter(client => client.id === userClientId)
            : product.clients;
          
          // Calculate metrics from relevant clients only
          const totalServers = relevantClients.reduce((acc, client) => 
            acc + client.environments.reduce((envAcc, env) => envAcc + env.servers.length, 0), 0);
          const totalEnvironments = relevantClients.reduce((acc, client) => 
            acc + client.environments.length, 0);
          const healthyServers = relevantClients.reduce((acc, client) => 
            acc + client.environments.reduce((envAcc, env) => 
              envAcc + env.servers.filter(s => s.status === "online").length, 0), 0);
          
          // Determine overall status
          const status = totalServers === 0 ? "unknown" :
                        healthyServers === totalServers ? "healthy" : 
                        (healthyServers / totalServers > 0.8) ? "warning" : "error";
          
          return (
            <Card 
              key={product.id} 
              className="hover-elevate cursor-pointer transition-all duration-200"
              onClick={() => {
                onProductSelect(product.id);
                setLocation('/infrastructure');
              }}
              data-testid={`card-product-${product.id}`}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Server className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{product.name}</CardTitle>
                    </div>
                  </div>
                  <Badge 
                    variant="outline" 
                    className={`text-xs ${getStatusColor(status)}`}
                  >
                    {status}
                  </Badge>
                </div>
                <CardDescription className="text-sm">
                  {product.description}
                </CardDescription>
              </CardHeader>
              
              <CardContent className="pt-0">
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <Server className="h-4 w-4 text-muted-foreground" />
                      <span className="text-2xl font-bold" data-testid={`text-server-count-${product.id}`}>
                        {totalServers}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground">Servers</p>
                  </div>
                  
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <Activity className="h-4 w-4 text-muted-foreground" />
                      <span className="text-2xl font-bold">
                        {totalEnvironments}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground">Environments</p>
                  </div>
                </div>
                
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full"
                  data-testid={`button-manage-${product.id}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    // Navigate to infrastructure page for this product
                    onProductSelect(product.id);
                    setLocation('/infrastructure');
                  }}
                >
                  Manage Infrastructure
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}