import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Server, 
  Cpu, 
  HardDrive, 
  Network, 
  Activity, 
  AlertTriangle,
  CheckCircle,
  XCircle,
  RefreshCw,
  Monitor,
  Database,
  Globe
} from "lucide-react";

interface InfraLayoutProps {
  selectedProduct?: string;
  selectedClient?: string;
  selectedEnvironment?: string;
  userSession?: any;
}

interface ServerStatus {
  id: string;
  name: string;
  type: "app" | "web" | "database" | "load-balancer";
  status: "online" | "offline" | "warning";
  ipAddress: string;
  cpu: number;
  memory: number;
  disk: number;
  network: number;
  uptime: string;
  lastCheck: Date;
}

// Mock server data
const mockServers: ServerStatus[] = [
  {
    id: "app-01",
    name: "Claims App Server 01",
    type: "app",
    status: "online",
    ipAddress: "10.0.1.10",
    cpu: 23,
    memory: 67,
    disk: 45,
    network: 12,
    uptime: "14d 6h 23m",
    lastCheck: new Date()
  },
  {
    id: "web-01",
    name: "Claims Web Server 01",
    type: "web",
    status: "online",
    ipAddress: "10.0.1.20",
    cpu: 15,
    memory: 42,
    disk: 38,
    network: 8,
    uptime: "14d 6h 23m",
    lastCheck: new Date()
  },
  {
    id: "db-01",
    name: "Claims DB Server 01",
    type: "database",
    status: "warning",
    ipAddress: "10.0.1.30",
    cpu: 78,
    memory: 85,
    disk: 92,
    network: 25,
    uptime: "14d 6h 23m",
    lastCheck: new Date()
  },
  {
    id: "lb-01",
    name: "Load Balancer 01",
    type: "load-balancer",
    status: "online",
    ipAddress: "10.0.1.5",
    cpu: 12,
    memory: 28,
    disk: 15,
    network: 45,
    uptime: "14d 6h 23m",
    lastCheck: new Date()
  }
];

export default function InfraLayout({
  selectedProduct,
  selectedClient,
  selectedEnvironment,
  userSession
}: InfraLayoutProps) {
  const [refreshing, setRefreshing] = useState(false);

  const handleRefresh = async () => {
    setRefreshing(true);
    // Simulate refresh
    await new Promise(resolve => setTimeout(resolve, 1000));
    setRefreshing(false);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "online": return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "warning": return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case "offline": return <XCircle className="h-4 w-4 text-red-500" />;
      default: return <Activity className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "online": return "outline";
      case "warning": return "secondary";
      case "offline": return "destructive";
      default: return "outline";
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "app": return <Cpu className="h-4 w-4" />;
      case "web": return <Globe className="h-4 w-4" />;
      case "database": return <Database className="h-4 w-4" />;
      case "load-balancer": return <Network className="h-4 w-4" />;
      default: return <Server className="h-4 w-4" />;
    }
  };

  const getMetricColor = (value: number) => {
    if (value > 80) return "text-red-500";
    if (value > 60) return "text-yellow-500";
    return "text-green-500";
  };

  const getOverallHealth = () => {
    const online = mockServers.filter(s => s.status === "online").length;
    const total = mockServers.length;
    return { online, total, percentage: Math.round((online / total) * 100) };
  };

  const health = getOverallHealth();

  return (
    <div className="flex flex-col h-full p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2" data-testid="text-page-title">
            <Monitor className="h-8 w-8 text-primary" />
            Infrastructure Layout
          </h1>
          <p className="text-muted-foreground mt-1">
            Real-time infrastructure monitoring and server health
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-sm">
            {selectedEnvironment ? `${selectedProduct} • ${selectedEnvironment}` : "No environment selected"}
          </Badge>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleRefresh}
            disabled={refreshing}
            data-testid="button-refresh-infra"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>
      </div>

      {/* Health Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">System Health</p>
                <p className="text-2xl font-bold text-green-600" data-testid="text-system-health">
                  {health.percentage}%
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {health.online}/{health.total} servers online
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Active Alerts</p>
                <p className="text-2xl font-bold text-yellow-600" data-testid="text-active-alerts">3</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-yellow-500" />
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              2 warnings, 1 critical
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Servers</p>
                <p className="text-2xl font-bold" data-testid="text-total-servers">{mockServers.length}</p>
              </div>
              <Server className="h-8 w-8 text-muted-foreground" />
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Across all environments
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Avg Response</p>
                <p className="text-2xl font-bold text-green-600" data-testid="text-avg-response">124ms</p>
              </div>
              <Activity className="h-8 w-8 text-green-500" />
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Last 15 minutes
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <div className="flex-1">
        <Tabs defaultValue="servers" className="h-full">
          <TabsList className="grid w-full grid-cols-3" data-testid="tabs-infra">
            <TabsTrigger value="servers" data-testid="tab-servers">
              <Server className="h-4 w-4 mr-2" />
              Servers
            </TabsTrigger>
            <TabsTrigger value="network" data-testid="tab-network">
              <Network className="h-4 w-4 mr-2" />
              Network
            </TabsTrigger>
            <TabsTrigger value="storage" data-testid="tab-storage">
              <HardDrive className="h-4 w-4 mr-2" />
              Storage
            </TabsTrigger>
          </TabsList>

          <TabsContent value="servers" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {mockServers.map((server) => (
                <Card key={server.id} className="hover-elevate" data-testid={`card-server-${server.id}`}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center gap-2 text-lg">
                        {getTypeIcon(server.type)}
                        {server.name}
                      </CardTitle>
                      <div className="flex items-center gap-2">
                        {getStatusIcon(server.status)}
                        <Badge variant={getStatusColor(server.status)}>
                          {server.status}
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {server.ipAddress} • {server.uptime}
                    </p>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm flex items-center gap-2">
                          <Cpu className="h-4 w-4" />
                          CPU
                        </span>
                        <span className={`text-sm font-bold ${getMetricColor(server.cpu)}`}>
                          {server.cpu}%
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm flex items-center gap-2">
                          <Activity className="h-4 w-4" />
                          Memory
                        </span>
                        <span className={`text-sm font-bold ${getMetricColor(server.memory)}`}>
                          {server.memory}%
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm flex items-center gap-2">
                          <HardDrive className="h-4 w-4" />
                          Disk
                        </span>
                        <span className={`text-sm font-bold ${getMetricColor(server.disk)}`}>
                          {server.disk}%
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm flex items-center gap-2">
                          <Network className="h-4 w-4" />
                          Network
                        </span>
                        <span className={`text-sm font-bold ${getMetricColor(server.network)}`}>
                          {server.network} MB/s
                        </span>
                      </div>
                      <div className="pt-2 border-t">
                        <p className="text-xs text-muted-foreground">
                          Last check: {server.lastCheck.toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="network" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Network Topology</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Network className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">Network Monitoring</h3>
                  <p className="text-muted-foreground">
                    Network topology and connection monitoring interface
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="storage" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Storage Systems</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <HardDrive className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">Storage Monitoring</h3>
                  <p className="text-muted-foreground">
                    Storage capacity, performance, and health monitoring
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}