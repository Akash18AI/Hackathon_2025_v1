import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ChatInterface } from "@/components/ChatInterface";
import { LogViewer } from "@/components/LogViewer";
import { PlaybookDashboard, type Playbook } from "@/components/PlaybookDashboard";
import { PlaybookExecutor } from "@/components/PlaybookExecutor";
import { PlaybookCreator } from "@/components/PlaybookCreator";

interface DashboardProps {
  selectedProduct?: string;
  selectedClient?: string;
  selectedEnvironment?: string;
  userSession?: any;
}

// Mock playbooks data based on actual DevOps operations - in real app this would come from your backend
const mockPlaybooks: Playbook[] = [
  {
    id: "service-restart",
    name: "Service Restart",
    description: "Gracefully restart specific Windows services or Linux daemons on target servers",
    category: "application",
    difficulty: "low",
    estimatedTime: "2-5 minutes",
    lastRun: new Date("2024-09-15"),
    successRate: 98,
    tags: ["service", "restart", "maintenance", "windows", "linux"]
  },
  {
    id: "process-restart",
    name: "Process Restart",
    description: "Kill and restart specific processes by name or PID across selected servers",
    category: "application",
    difficulty: "low",
    estimatedTime: "1-3 minutes",
    lastRun: new Date("2024-09-15"),
    successRate: 95,
    tags: ["process", "restart", "maintenance", "kill"]
  },
  {
    id: "apppool-stop",
    name: "Application Pool Stop",
    description: "Stop IIS Application Pool on Windows servers for maintenance",
    category: "application",
    difficulty: "low",
    estimatedTime: "1-2 minutes",
    lastRun: new Date("2024-09-15"),
    successRate: 99,
    tags: ["apppool", "iis", "stop", "windows", "maintenance"]
  },
  {
    id: "apppool-start",
    name: "Application Pool Start",
    description: "Start IIS Application Pool on Windows servers after maintenance",
    category: "application",
    difficulty: "low",
    estimatedTime: "1-2 minutes",
    lastRun: new Date("2024-09-15"),
    successRate: 99,
    tags: ["apppool", "iis", "start", "windows", "maintenance"]
  },
  {
    id: "application-restart",
    name: "Application Restart",
    description: "Full restart of Insurity applications including web services and background processes",
    category: "application",
    difficulty: "medium",
    estimatedTime: "3-8 minutes",
    lastRun: new Date("2024-09-14"),
    successRate: 92,
    tags: ["application", "restart", "full-stack", "insurity"]
  },
  {
    id: "clear-disk-space",
    name: "Clear Disk Space",
    description: "Clean up log files, temporary files, and old backups to free disk space",
    category: "system",
    difficulty: "low", 
    estimatedTime: "5-15 minutes",
    lastRun: new Date("2024-09-14"),
    successRate: 96,
    tags: ["cleanup", "disk-space", "logs", "maintenance"]
  },
  {
    id: "database-backup",
    name: "Database Backup",
    description: "Create full database backup with verification for selected environment",
    category: "database",
    difficulty: "medium",
    estimatedTime: "15-30 minutes",
    lastRun: new Date("2024-09-14"),
    successRate: 94,
    tags: ["backup", "database", "critical", "verification"]
  },
  {
    id: "log-rotation",
    name: "Log Rotation & Archive",
    description: "Rotate application logs and archive old log files to prevent disk space issues",
    category: "system",
    difficulty: "low",
    estimatedTime: "3-10 minutes",
    lastRun: new Date("2024-09-15"),
    successRate: 97,
    tags: ["logs", "rotation", "archive", "maintenance"]
  },
  {
    id: "health-check-services",
    name: "Service Health Check",
    description: "Verify all critical services are running and responding properly",
    category: "monitoring",
    difficulty: "low",
    estimatedTime: "2-5 minutes",
    lastRun: new Date("2024-09-15"),
    successRate: 99,
    tags: ["health-check", "services", "monitoring", "verification"]
  },
  {
    id: "memory-cleanup",
    name: "Memory Cleanup",
    description: "Clear memory caches and restart memory-intensive processes",
    category: "performance",
    difficulty: "medium",
    estimatedTime: "3-7 minutes",
    lastRun: new Date("2024-09-15"),
    successRate: 89,
    tags: ["memory", "performance", "cache", "cleanup"]
  }
]; // todo: remove mock functionality

export default function Dashboard({ 
  selectedProduct, 
  selectedClient, 
  selectedEnvironment, 
  userSession 
}: DashboardProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeExecution, setActiveExecution] = useState();

  const handleLogQuery = (query: string, productId?: string) => {
    console.log(`AI analyzing logs: "${query}" for product: ${productId}`);
    setSearchQuery(query);
  };

  const handleExecutePlaybook = (playbookId: string) => {
    console.log(`Starting execution of playbook: ${playbookId}`);
    // In real app, this would trigger the actual Ansible playbook execution
    // via your FastAPI backend
  };

  const handleSavePlaybook = (playbook: any) => {
    console.log(`Saving new AI-generated playbook: ${playbook.name}`);
    // In real app, this would save the playbook to your backend
    // and refresh the playbook list
  };

  if (!selectedProduct || !selectedClient || !selectedEnvironment) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center text-muted-foreground">
          <div className="h-12 w-12 mx-auto mb-4 rounded-lg bg-muted flex items-center justify-center">
            🏢
          </div>
          <h2 className="text-lg font-semibold mb-2">Select Environment</h2>
          <p className="text-sm">
            {!selectedProduct ? "Choose a product from the sidebar to begin" :
             !selectedClient ? "Select a client to continue" :
             "Select an environment to start analyzing logs and executing playbooks"}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex gap-6 p-6 min-h-0">
      {/* Left Panel - AI Chat & Log Analysis */}
      <div className="flex-1 flex flex-col gap-6 min-w-0">
        <div className="flex-1">
          <ChatInterface 
            selectedProduct={selectedProduct}
            selectedClient={selectedClient}
            selectedEnvironment={selectedEnvironment}
            onLogQuery={handleLogQuery}
          />
        </div>
        
        <div className="flex-1">
          <LogViewer 
            selectedProduct={selectedProduct}
            selectedClient={selectedClient}
            selectedEnvironment={selectedEnvironment}
            searchQuery={searchQuery}
          />
        </div>
      </div>

      {/* Right Panel - Playbooks & Execution */}
      <div className="w-96 flex flex-col gap-6">
        <Tabs defaultValue="existing" className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="existing" data-testid="tab-existing-playbooks">
              Existing Playbooks
            </TabsTrigger>
            <TabsTrigger value="create" data-testid="tab-create-playbook">
              Create with AI
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="existing" className="flex-1 flex flex-col gap-6 mt-4">
            <div className="flex-1">
              <PlaybookDashboard 
                playbooks={mockPlaybooks}
                onExecutePlaybook={handleExecutePlaybook}
              />
            </div>
            
            <div className="h-80">
              <PlaybookExecutor 
                execution={activeExecution}
              />
            </div>
          </TabsContent>
          
          <TabsContent value="create" className="flex-1 mt-4">
            <PlaybookCreator
              selectedProduct={selectedProduct}
              selectedClient={selectedClient}
              selectedEnvironment={selectedEnvironment}
              onSavePlaybook={handleSavePlaybook}
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}