import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ChevronRight, Server, Users, Building } from "lucide-react";
import type { Product } from "@/components/ProductSelector";

interface ProductsProps {
  products: Product[];
  userRole?: "admin" | "client";
  userClientId?: string;
}

export default function Products({ products, userRole, userClientId }: ProductsProps) {
  const [selectedProduct, setSelectedProduct] = useState<string | null>(null);
  const [selectedClient, setSelectedClient] = useState<string | null>(null);

  // Filter products based on user role
  const filteredProducts = userRole === "client" && userClientId
    ? products.filter(product => 
        product.clients.some(client => client.id === userClientId)
      )
    : products;

  const selectedProductData = selectedProduct 
    ? filteredProducts.find(p => p.id === selectedProduct)
    : null;

  const selectedClientData = selectedClient && selectedProductData
    ? selectedProductData.clients.find(c => c.id === selectedClient)
    : null;

  if (selectedClientData && selectedClient) {
    // Show Environments and Servers view
    return (
      <div className="flex-1 p-6">
        <div className="mb-6">
          <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
            <button 
              onClick={() => {
                setSelectedProduct(null);
                setSelectedClient(null);
              }}
              className="hover:text-foreground"
              data-testid="button-back-to-products"
            >
              Products
            </button>
            <ChevronRight className="h-4 w-4" />
            <button 
              onClick={() => setSelectedClient(null)}
              className="hover:text-foreground"
              data-testid="button-back-to-clients"
            >
              {selectedProductData?.name}
            </button>
            <ChevronRight className="h-4 w-4" />
            <span className="text-foreground">{selectedClientData.name}</span>
          </nav>

          <h1 className="text-3xl font-bold mb-2" data-testid="text-environments-title">
            {selectedClientData.name} - {selectedProductData?.name}
          </h1>
          <p className="text-muted-foreground">
            Environments and server infrastructure
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {selectedClientData.environments.map((environment) => (
            <Card key={environment.id} className="hover-elevate">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{environment.name}</CardTitle>
                  <Badge variant="outline" className="text-xs">
                    {environment.type}
                  </Badge>
                </div>
              </CardHeader>
              
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center p-4 bg-muted/50 rounded-lg">
                    <div className="flex items-center justify-center gap-2 mb-2">
                      <Server className="h-5 w-5 text-muted-foreground" />
                      <span className="text-2xl font-bold" data-testid={`text-server-count-${environment.id}`}>
                        {environment.servers.length}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">Servers</p>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-medium text-sm">Servers:</h4>
                    {environment.servers.map((server) => (
                      <div 
                        key={server.id} 
                        className="flex items-center justify-between text-sm p-2 bg-background border rounded"
                        data-testid={`server-item-${server.id}`}
                      >
                        <span className="font-medium">{server.name}</span>
                        <Badge 
                          variant={
                            server.status === "online" ? "default" :
                            server.status === "warning" ? "secondary" : "destructive"
                          }
                          className="text-xs"
                        >
                          {server.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (selectedProductData) {
    // Show Clients view
    const clientsForProduct = userRole === "client" && userClientId
      ? selectedProductData.clients.filter(client => client.id === userClientId)
      : selectedProductData.clients;

    return (
      <div className="flex-1 p-6">
        <div className="mb-6">
          <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
            <button 
              onClick={() => setSelectedProduct(null)}
              className="hover:text-foreground"
              data-testid="button-back-to-products"
            >
              Products
            </button>
            <ChevronRight className="h-4 w-4" />
            <span className="text-foreground">{selectedProductData.name}</span>
          </nav>

          <h1 className="text-3xl font-bold mb-2" data-testid="text-clients-title">
            {selectedProductData.name} - Client Organizations
          </h1>
          <p className="text-muted-foreground">
            {selectedProductData.description}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {clientsForProduct.map((client) => (
            <Card 
              key={client.id} 
              className="hover-elevate cursor-pointer"
              onClick={() => setSelectedClient(client.id)}
              data-testid={`card-client-${client.id}`}
            >
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Building className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{client.name}</CardTitle>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold mb-1">
                      {client.environments.length}
                    </div>
                    <p className="text-xs text-muted-foreground">Environments</p>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-2xl font-bold mb-1">
                      {client.environments.reduce((total, env) => total + env.servers.length, 0)}
                    </div>
                    <p className="text-xs text-muted-foreground">Servers</p>
                  </div>
                </div>
                
                <Button variant="outline" size="sm" className="w-full">
                  View Environments
                  <ChevronRight className="h-4 w-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  // Show Products view
  return (
    <div className="flex-1 p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2" data-testid="text-products-title">Products</h1>
        <p className="text-muted-foreground">
          Browse products and their client organizations
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProducts.map((product) => (
          <Card 
            key={product.id} 
            className="hover-elevate cursor-pointer"
            onClick={() => setSelectedProduct(product.id)}
            data-testid={`card-product-${product.id}`}
          >
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Server className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <CardTitle className="text-lg">{product.name}</CardTitle>
                </div>
              </div>
            </CardHeader>
            
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                {product.description}
              </p>
              
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="text-center">
                  <div className="text-2xl font-bold mb-1">
                    {product.clients.length}
                  </div>
                  <p className="text-xs text-muted-foreground">Clients</p>
                </div>
                
                <div className="text-center">
                  <div className="text-2xl font-bold mb-1">
                    {product.clients.reduce((total, client) => 
                      total + client.environments.reduce((envTotal, env) => envTotal + env.servers.length, 0), 0
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">Servers</p>
                </div>
              </div>
              
              <Button variant="outline" size="sm" className="w-full">
                View Clients
                <ChevronRight className="h-4 w-4 ml-2" />
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}