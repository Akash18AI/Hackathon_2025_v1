import { useState, useEffect } from "react";
import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { LogOut } from "lucide-react";
import { ThemeProvider } from "@/components/ThemeProvider";
import { ThemeToggle } from "@/components/ThemeToggle";
import { AppSidebar } from "@/components/AppSidebar";
import { UserLogin, type UserSession } from "@/components/UserLogin";
import { LayoutSwitcher } from "@/components/LayoutSwitcher";
import { TopNavLayout } from "@/components/layouts/TopNavLayout";
import { CentralHubLayout } from "@/components/layouts/CentralHubLayout";
import { SplitLayout } from "@/components/layouts/SplitLayout";
import Dashboard from "@/pages/Dashboard";
import AIAnalysis from "@/pages/AIAnalysis";
import AILogsViewer from "@/pages/AILogsViewer";
import Playbooks from "@/pages/Playbooks";
import InfraLayout from "@/pages/InfraLayout";
import ProductInfrastructure from "@/pages/ProductInfrastructure";
import ProductOverview from "@/pages/ProductOverview";
import Products from "@/pages/Products";
import NotFound from "@/pages/not-found";
import type { Product } from "@/components/ProductSelector";

// Mock products data based on actual Insurity products - in real app this would come from your backend API
const mockProducts: Product[] = [
  {
    id: "surepatc",
    name: "SurePALC",
    description: "Insurance policy patching and management system",
    clients: [
      {
        id: "apple",
        name: "Apple Inc.",
        environments: [
          {
            id: "surepatc-test",
            name: "Test Environment",
            type: "Test",
            logPath: "/shared/logs/surepatc/apple/test/",
            servers: [
              { id: "surepatc-app-test-01", name: "SurePALC App Test 01", type: "app", status: "online", ipAddress: "10.0.1.10" },
              { id: "surepatc-web-test-01", name: "SurePALC Web Test 01", type: "web", status: "online", ipAddress: "10.0.1.11" },
              { id: "surepatc-db-test-01", name: "SurePALC DB Test 01", type: "database", status: "online", ipAddress: "10.0.1.12" }
            ]
          },
          {
            id: "surepatc-preprod",
            name: "Pre-Production",
            type: "PreProd",
            logPath: "/shared/logs/surepatc/apple/preprod/",
            servers: [
              { id: "surepatc-app-preprod-01", name: "SurePALC App PreProd 01", type: "app", status: "warning", ipAddress: "10.0.2.10" },
              { id: "surepatc-web-preprod-01", name: "SurePALC Web PreProd 01", type: "web", status: "online", ipAddress: "10.0.2.11" },
              { id: "surepatc-db-preprod-01", name: "SurePALC DB PreProd 01", type: "database", status: "online", ipAddress: "10.0.2.12" }
            ]
          },
          {
            id: "surepatc-prod",
            name: "Production",
            type: "Prod",
            logPath: "/shared/logs/surepatc/apple/prod/",
            servers: [
              { id: "surepatc-app-prod-01", name: "SurePALC App Prod 01", type: "app", status: "online", ipAddress: "10.0.3.10" },
              { id: "surepatc-app-prod-02", name: "SurePALC App Prod 02", type: "app", status: "online", ipAddress: "10.0.3.15" },
              { id: "surepatc-web-prod-01", name: "SurePALC Web Prod 01", type: "web", status: "online", ipAddress: "10.0.3.11" },
              { id: "surepatc-db-prod-01", name: "SurePALC DB Prod 01", type: "database", status: "online", ipAddress: "10.0.3.12" },
              { id: "surepatc-apppool-prod-01", name: "SurePALC App Pool 01", type: "apppool", status: "online", ipAddress: "10.0.3.13" }
            ]
          }
        ]
      }
    ]
  },
  {
    id: "bin",
    name: "BIN",
    description: "Business Intelligence and Analytics Platform",
    clients: [
      {
        id: "google",
        name: "Google LLC", 
        environments: [
          {
            id: "bin-test",
            name: "Test Environment",
            type: "Test",
            logPath: "/shared/logs/bin/google/test/",
            servers: [
              { id: "bin-app-test-01", name: "BIN App Test 01", type: "app", status: "online", ipAddress: "10.0.1.20" },
              { id: "bin-rsp-test-01", name: "BIN RSP Test 01", type: "rsp", status: "online", ipAddress: "10.0.1.21" }
            ]
          },
          {
            id: "bin-prod",
            name: "Production",
            type: "Prod",
            logPath: "/shared/logs/bin/google/prod/",
            servers: [
              { id: "bin-app-prod-01", name: "BIN App Prod 01", type: "app", status: "online", ipAddress: "10.0.3.20" },
              { id: "bin-web-prod-01", name: "BIN Web Prod 01", type: "web", status: "online", ipAddress: "10.0.3.21" },
              { id: "bin-rsp-prod-01", name: "BIN RSP Prod 01", type: "rsp", status: "warning", ipAddress: "10.0.3.22" }
            ]
          }
        ]
      }
    ]
  },
  {
    id: "claims",
    name: "Claims",
    description: "Insurance claims processing and management system",
    clients: [
      {
        id: "apple",
        name: "Apple Inc.",
        environments: [
          {
            id: "claims-test",
            name: "Test Environment", 
            type: "Test",
            logPath: "/shared/logs/claims/apple/test/",
            servers: [
              { id: "claims-app-test-01", name: "Claims App Test 01", type: "app", status: "online", ipAddress: "10.0.1.30" },
              { id: "claims-web-test-01", name: "Claims Web Test 01", type: "web", status: "online", ipAddress: "10.0.1.31" }
            ]
          },
          {
            id: "claims-preprod",
            name: "Pre-Production",
            type: "PreProd", 
            logPath: "/shared/logs/claims/apple/preprod/",
            servers: [
              { id: "claims-app-preprod-01", name: "Claims App PreProd 01", type: "app", status: "error", ipAddress: "10.0.2.30" },
              { id: "claims-web-preprod-01", name: "Claims Web PreProd 01", type: "web", status: "online", ipAddress: "10.0.2.31" },
              { id: "claims-db-preprod-01", name: "Claims DB PreProd 01", type: "database", status: "online", ipAddress: "10.0.2.32" }
            ]
          },
          {
            id: "claims-prod",
            name: "Production",
            type: "Prod",
            logPath: "/shared/logs/claims/apple/prod/",
            servers: [
              { id: "claims-app-prod-01", name: "Claims App Prod 01", type: "app", status: "online", ipAddress: "10.0.3.30" },
              { id: "claims-app-prod-02", name: "Claims App Prod 02", type: "app", status: "online", ipAddress: "10.0.3.35" },
              { id: "claims-web-prod-01", name: "Claims Web Prod 01", type: "web", status: "online", ipAddress: "10.0.3.31" },
              { id: "claims-db-prod-01", name: "Claims DB Prod 01", type: "database", status: "online", ipAddress: "10.0.3.32" },
              { id: "claims-apppool-prod-01", name: "Claims App Pool 01", type: "apppool", status: "online", ipAddress: "10.0.3.33" }
            ]
          }
        ]
      },
      {
        id: "microsoft",
        name: "Microsoft Corporation",
        environments: [
          {
            id: "claims-test-ms",
            name: "Test Environment", 
            type: "Test",
            logPath: "/shared/logs/claims/microsoft/test/",
            servers: [
              { id: "claims-app-test-ms-01", name: "Claims App Test MS 01", type: "app", status: "online", ipAddress: "10.0.1.130" },
              { id: "claims-web-test-ms-01", name: "Claims Web Test MS 01", type: "web", status: "online", ipAddress: "10.0.1.131" }
            ]
          },
          {
            id: "claims-prod-ms",
            name: "Production",
            type: "Prod",
            logPath: "/shared/logs/claims/microsoft/prod/",
            servers: [
              { id: "claims-app-prod-ms-01", name: "Claims App Prod MS 01", type: "app", status: "online", ipAddress: "10.0.3.130" },
              { id: "claims-web-prod-ms-01", name: "Claims Web Prod MS 01", type: "web", status: "online", ipAddress: "10.0.3.131" },
              { id: "claims-db-prod-ms-01", name: "Claims DB Prod MS 01", type: "database", status: "online", ipAddress: "10.0.3.132" }
            ]
          }
        ]
      }
    ]
  },
  {
    id: "qlik",
    name: "Qlik",
    description: "Business intelligence and data visualization platform",
    clients: [
      {
        id: "google",
        name: "Google LLC",
        environments: [
          {
            id: "qlik-prod",
            name: "Production",
            type: "Prod",
            logPath: "/shared/logs/qlik/google/prod/",
            servers: [
              { id: "qlik-app-prod-01", name: "Qlik Server Prod 01", type: "app", status: "online", ipAddress: "10.0.3.40" },
              { id: "qlik-web-prod-01", name: "Qlik Web Prod 01", type: "web", status: "maintenance", ipAddress: "10.0.3.41" }
            ]
          }
        ]
      }
    ]
  },
  {
    id: "underwriting",
    name: "Underwriting",
    description: "Insurance underwriting and risk assessment system",
    clients: [
      {
        id: "microsoft", 
        name: "Microsoft Corporation",
        environments: [
          {
            id: "underwriting-test",
            name: "Test Environment",
            type: "Test",
            logPath: "/shared/logs/underwriting/microsoft/test/",
            servers: [
              { id: "underwriting-app-test-01", name: "Underwriting App Test 01", type: "app", status: "online", ipAddress: "10.0.1.50" },
              { id: "underwriting-db-test-01", name: "Underwriting DB Test 01", type: "database", status: "online", ipAddress: "10.0.1.51" }
            ]
          },
          {
            id: "underwriting-prod", 
            name: "Production",
            type: "Prod",
            logPath: "/shared/logs/underwriting/microsoft/prod/",
            servers: [
              { id: "underwriting-app-prod-01", name: "Underwriting App Prod 01", type: "app", status: "online", ipAddress: "10.0.3.50" },
              { id: "underwriting-web-prod-01", name: "Underwriting Web Prod 01", type: "web", status: "online", ipAddress: "10.0.3.51" },
              { id: "underwriting-db-prod-01", name: "Underwriting DB Prod 01", type: "database", status: "online", ipAddress: "10.0.3.52" }
            ]
          }
        ]
      }
    ]
  }
]; // todo: remove mock functionality

function Router({ 
  selectedProduct, 
  selectedClient, 
  selectedEnvironment, 
  userSession,
  currentLayout,
  onLayoutChange,
  onSelectionChange
}: { 
  selectedProduct?: string;
  selectedClient?: string;
  selectedEnvironment?: string;
  userSession?: any;
  currentLayout?: string;
  onLayoutChange?: (layout: string) => void;
  onSelectionChange: (selection: { productId?: string; clientId?: string; environmentId?: string }) => void;
}) {
  const [, setLocation] = useLocation();
  
  return (
    <Switch>
      <Route path="/" component={() => {
        // Filter products by client for client users
        const filteredProducts = userSession?.role === "client" && userSession?.clientId
          ? mockProducts.filter(product => 
              product.clients.some(client => client.id === userSession.clientId)
            )
          : mockProducts;

        return userSession?.role === "admin" ? (
          <ProductOverview 
            products={mockProducts}
            userRole={userSession.role}
            onProductSelect={(productId) => {
              const product = mockProducts.find(p => p.id === productId);
              if (product && product.clients.length > 0) {
                onSelectionChange({
                  productId,
                  clientId: product.clients[0].id,
                  environmentId: product.clients[0].environments[0]?.id
                });
                setLocation('/dashboard');
              }
            }}
          />
        ) : (
          <ProductOverview 
            products={filteredProducts}
            userRole={userSession?.role}
            userClientName={userSession?.clientName}
            userClientId={userSession?.clientId}
            onProductSelect={(productId) => {
              const product = filteredProducts.find(p => p.id === productId);
              if (product && userSession?.clientId) {
                const clientData = product.clients.find(c => c.id === userSession.clientId);
                if (clientData) {
                  onSelectionChange({
                    productId,
                    clientId: userSession.clientId,
                    environmentId: clientData.environments[0]?.id
                  });
                  setLocation('/dashboard');
                }
              }
            }}
          />
        );
      }} />
      <Route path="/dashboard" component={() => 
        <Dashboard 
          selectedProduct={selectedProduct}
          selectedClient={selectedClient}
          selectedEnvironment={selectedEnvironment}
          userSession={userSession}
        />
      } />
      <Route path="/ai-analysis" component={() => 
        <AIAnalysis 
          selectedProduct={selectedProduct}
          selectedClient={selectedClient}
          selectedEnvironment={selectedEnvironment}
          userSession={userSession}
        />
      } />
      <Route path="/logs" component={() => 
        <AILogsViewer 
          selectedProduct={selectedProduct}
          selectedClient={selectedClient}
          selectedEnvironment={selectedEnvironment}
          userSession={userSession}
        />
      } />
      <Route path="/playbooks" component={() => 
        <Playbooks 
          selectedProduct={selectedProduct}
          selectedClient={selectedClient}
          selectedEnvironment={selectedEnvironment}
          userSession={userSession}
        />
      } />
      <Route path="/monitoring" component={() => 
        <InfraLayout 
          selectedProduct={selectedProduct}
          selectedClient={selectedClient}
          selectedEnvironment={selectedEnvironment}
          userSession={userSession}
        />
      } />
      <Route path="/infrastructure" component={() => 
        <ProductInfrastructure 
          selectedProduct={selectedProduct}
          userSession={userSession}
          products={mockProducts}
          onSelectionChange={onSelectionChange}
        />
      } />
      <Route path="/products" component={() => 
        <Products 
          products={mockProducts}
          userRole={userSession?.role}
          userClientId={userSession?.clientId}
        />
      } />
      <Route path="/layouts" component={() => 
        <LayoutSwitcher 
          currentLayout={currentLayout || "sidebar"}
          onLayoutChange={onLayoutChange || (() => {})}
        />
      } />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [userSession, setUserSession] = useState<UserSession>();
  const [currentLayout, setCurrentLayout] = useState<string>("sidebar");

  // Load user session and layout from sessionStorage on app start
  useEffect(() => {
    const savedSession = sessionStorage.getItem('userSession');
    const savedLayout = sessionStorage.getItem('currentLayout');
    
    if (savedSession) {
      try {
        const parsedSession = JSON.parse(savedSession);
        setUserSession(parsedSession);
      } catch (error) {
        console.error('Failed to parse saved session:', error);
        sessionStorage.removeItem('userSession');
      }
    }
    
    if (savedLayout) {
      setCurrentLayout(savedLayout);
    }
  }, []);

  // Save user session to sessionStorage whenever it changes
  useEffect(() => {
    if (userSession) {
      sessionStorage.setItem('userSession', JSON.stringify(userSession));
    } else {
      sessionStorage.removeItem('userSession');
    }
  }, [userSession]);

  // Save layout preference to sessionStorage
  useEffect(() => {
    sessionStorage.setItem('currentLayout', currentLayout);
  }, [currentLayout]);
  const [selectedProduct, setSelectedProduct] = useState<string>();
  const [selectedClient, setSelectedClient] = useState<string>();
  const [selectedEnvironment, setSelectedEnvironment] = useState<string>();

  // Load selections from sessionStorage on app start
  useEffect(() => {
    const savedProduct = sessionStorage.getItem('selectedProduct');
    const savedClient = sessionStorage.getItem('selectedClient');
    const savedEnvironment = sessionStorage.getItem('selectedEnvironment');
    
    if (savedProduct) setSelectedProduct(savedProduct);
    if (savedClient) setSelectedClient(savedClient);
    if (savedEnvironment) setSelectedEnvironment(savedEnvironment);
  }, []);

  // Save selections to sessionStorage whenever they change
  useEffect(() => {
    if (selectedProduct) {
      sessionStorage.setItem('selectedProduct', selectedProduct);
    } else {
      sessionStorage.removeItem('selectedProduct');
    }
  }, [selectedProduct]);

  useEffect(() => {
    if (selectedClient) {
      sessionStorage.setItem('selectedClient', selectedClient);
    } else {
      sessionStorage.removeItem('selectedClient');
    }
  }, [selectedClient]);

  useEffect(() => {
    if (selectedEnvironment) {
      sessionStorage.setItem('selectedEnvironment', selectedEnvironment);
    } else {
      sessionStorage.removeItem('selectedEnvironment');
    }
  }, [selectedEnvironment]);
  
  // Custom sidebar width for the DevOps dashboard
  const style = {
    "--sidebar-width": "22rem",       // 352px for better product display
    "--sidebar-width-icon": "4rem",   // default icon width
  };

  const handleSelectionChange = (selection: {
    productId?: string;
    clientId?: string;
    environmentId?: string;
  }) => {
    setSelectedProduct(selection.productId);
    setSelectedClient(selection.clientId);
    setSelectedEnvironment(selection.environmentId);
  };

  const handleLogout = () => {
    // Clear session storage
    sessionStorage.removeItem('userSession');
    sessionStorage.removeItem('selectedProduct');
    sessionStorage.removeItem('selectedClient');
    sessionStorage.removeItem('selectedEnvironment');
    
    // Clear state
    setUserSession(undefined);
    setSelectedProduct(undefined);
    setSelectedClient(undefined);
    setSelectedEnvironment(undefined);
  };

  const getCurrentContext = () => {
    if (!selectedProduct) return "Select a product to begin";
    
    const product = mockProducts.find(p => p.id === selectedProduct);
    const client = selectedClient ? product?.clients.find(c => c.id === selectedClient) : undefined;
    const environment = selectedEnvironment && client ? 
      client.environments.find(e => e.id === selectedEnvironment) : undefined;
    
    let context = product?.name || "Unknown Product";
    if (client) context += ` • ${client.name}`;
    if (environment) context += ` • ${environment.name} (${environment.type})`;
    
    return context;
  };

  if (!userSession) {
    return (
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <ThemeProvider defaultTheme="dark">
            <UserLogin onLogin={setUserSession} />
            <Toaster />
          </ThemeProvider>
        </TooltipProvider>
      </QueryClientProvider>
    );
  }

  const renderLayout = () => {
    const routerComponent = (
      <Router 
        selectedProduct={selectedProduct}
        selectedClient={selectedClient}
        selectedEnvironment={selectedEnvironment}
        userSession={userSession}
        currentLayout={currentLayout}
        onLayoutChange={setCurrentLayout}
        onSelectionChange={handleSelectionChange}
      />
    );

    const layoutProps = {
      products: mockProducts,
      selectedProduct,
      selectedClient,
      selectedEnvironment,
      userSession,
      userRole: userSession.role,
      userClientId: userSession.clientId,
      onSelectionChange: handleSelectionChange,
      onLogout: handleLogout,
      children: routerComponent
    };

    switch (currentLayout) {
      case "topnav":
        return <TopNavLayout {...layoutProps} />;
      case "central":
        return <CentralHubLayout {...layoutProps} />;
      case "split":
        return <SplitLayout {...layoutProps} />;
      case "sidebar":
      default:
        return (
          <SidebarProvider style={style as React.CSSProperties}>
            <div className="flex h-screen w-full">
              <AppSidebar 
                products={mockProducts}
                selectedProduct={selectedProduct}
                selectedClient={selectedClient}
                selectedEnvironment={selectedEnvironment}
                userRole={userSession.role}
                userClientId={userSession.clientId}
                onSelectionChange={handleSelectionChange}
                userSession={userSession}
              />
              <div className="flex flex-col flex-1 min-w-0">
                <header className="flex items-center justify-between p-4 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
                  <div className="flex items-center gap-2">
                    <SidebarTrigger data-testid="button-sidebar-toggle" />
                    <div>
                      <h1 className="font-semibold text-lg">OpsIntelligence Platform</h1>
                      <p className="text-xs text-muted-foreground">
                        {getCurrentContext()}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground">{userSession.username}</p>
                      <p className="text-xs text-muted-foreground capitalize">{userSession.role}</p>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={handleLogout}
                      className="text-muted-foreground hover:text-foreground"
                      data-testid="button-logout"
                    >
                      <LogOut className="h-4 w-4 mr-1" />
                      <span className="hidden sm:inline">Logout</span>
                    </Button>
                    <ThemeToggle />
                  </div>
                </header>
                <main className="flex-1 overflow-hidden">
                  {routerComponent}
                </main>
              </div>
            </div>
          </SidebarProvider>
        );
    }
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <ThemeProvider defaultTheme="dark">
          {renderLayout()}
          <Toaster />
        </ThemeProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
